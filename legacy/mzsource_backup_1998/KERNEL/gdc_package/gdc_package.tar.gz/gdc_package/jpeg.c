/*
 Title                               : jpeg.c                                  MZLIB 
 MZLIB Source by                     : Jae Hyuk CHO                            �� �� �� 
 Copyright                           : Information Equipment co.,LTD.          (��) ������ť 
 Update                              : 2001.07.10 - New             
				       
 !RAW!
  DEF_ : Define
  t_   : typedef
  tx_  : typedef first field type - `x'    ( Ex: typedef enum -> typedef enum te_Bool{.......}t_Bool; )
  g_   : Global
  s_   : Local
  c_   : Const

 E-Mail : minzkn@dreamwiz.com
          minzkn@infoeq.com
	  minzkn@infoeq.co.kr 
*/

#ifndef DEF_jpeg_c                                     /* Already include ???                  */
#define DEF_jpeg_c                   "jpeg.c"              

#include                             "jpeg.h"            

// ��ü���� �ڿ� ����� ���¸� Ȯ���Ϸ��� �̰� 1�� �ϰ� �ƴϸ� 0(Default) - Debug on STATUS
#define DEF_JPEG_CHECK               1 

#if DEF_JPEG_CHECK == 1
 #define DEF_JPEG_ADD(x)             g_JPEG_UsedMemory+=((t_ulong)(x)); if(g_JPEG_UsedMemory > g_JPEG_MaxMemory)g_JPEG_MaxMemory = g_JPEG_UsedMemory
 #define DEF_JPEG_SUB(x)             g_JPEG_UsedMemory-=((t_ulong)(x))
 t_ulong                             g_JPEG_UsedMemory_ = (t_ulong)0;
 t_ulong                             g_JPEG_MaxMemory_ = (t_ulong)0;
 #define g_JPEG_UsedMemory           g_JPEG_UsedMemory_
 #define g_JPEG_MaxMemory            g_JPEG_MaxMemory_
#else
 #define DEF_JPEG_ADD(x)             {}  
 #define DEF_JPEG_SUB(x)             {}
 #define g_JPEG_UsedMemory           ((t_ulong)0)
 #define g_JPEG_MaxMemory            ((t_ulong)0)
#endif

/* Memory */
void *JPEG_Malloc(int s_Length);
void JPEG_Free(void *s_Ptr);
/* Report */
t_ulong JPEG_ReportMemory(t_void); 
/* File */
t_void *JPEG_LoadFromFile(t_void *s_FileName, t_size *s_GetSize);
t_void *JPEG_LoadFree(t_void *s_LoadFromXXXX, t_size s_LoadSize);
/* Decoder */
t_void JPEG_ConvertColor(t_JPEG_ConvertColorType s_ConvertType, t_float *s_0, t_float *s_1, t_float *s_2, t_int *s_Index);
t_JPEG_Node *JPEG_Node(t_JPEG_Node *s_JPEG_Node, t_void *s_DumpImage, t_ulong s_Start, t_ulong s_End); 

/* Link - GDC */

void *JPEG_Malloc(int s_Length)
{
 return(malloc(s_Length));   
}

void JPEG_Free(void *s_Ptr)
{
 free(s_Ptr);   
}

t_ulong JPEG_ReportMemory(t_void)
{
 return(g_JPEG_MaxMemory);   
}

t_void *JPEG_LoadFromFile(t_void *s_FileName, t_size *s_GetSize)
{ // ���Ϸκ��� Jpeg�̹����� �н��ϴ�.
 t_handle s_HANDLE_JPEG_File;
 t_void *s_Return = (t_void *)0;
 s_HANDLE_JPEG_File = open(s_FileName , O_RDONLY);
 if(s_HANDLE_JPEG_File >= 0)
 {
  t_size s_FileSize = (t_size)lseek(s_HANDLE_JPEG_File, (t_size)0, SEEK_END);
  if(lseek(s_HANDLE_JPEG_File, (t_size)0, SEEK_SET) == (t_size)0)
  {
   s_Return = (t_void *)JPEG_Malloc((t_size)s_FileSize);
   if(s_Return)
   {
    DEF_JPEG_ADD(s_FileSize);   
    (*s_GetSize) = (t_size)read(s_HANDLE_JPEG_File, s_Return, (t_size)s_FileSize); 
   }
  }   
  close(s_HANDLE_JPEG_File);    
 }
 return(s_Return);
}

t_void *JPEG_LoadFree(t_void *s_LoadFromXXXX, t_size s_DumpSize)
{ // ���Ϸκ��� �о��� �̹����� �޸𸮿��� �����մϴ�.
 JPEG_Free(s_LoadFromXXXX);
 DEF_JPEG_SUB(s_DumpSize); 
 return((t_void *)0);    
}

t_void JPEG_ConvertColor(t_JPEG_ConvertColorType s_ConvertType, t_float *s_0, t_float *s_1, t_float *s_2, t_int *s_Index)
{ // ���� ��ȯ - �ణ�� ���� �ս��� �ü� ������ ������ 0.01% ����
 /* ����
      - YIQ & RGB Model
        [Y] = [0.299    0.587   0.114]  [R]
        [I] = [0.596   -0.275   0.321]  [G]
        [Q] = [0.212   -0.523   0.311]  [B]  
 */
 switch(s_ConvertType)
 {
  case E_JPEG_YIQ2RGB:
       if(s_0 && s_1 && s_2)
       {
        t_float s_c0, s_c1, s_c2;
        s_c0 = *(s_0); s_c1 = *(s_1); s_c2 = *(s_2); 
        *(s_0) = (s_c0 * 0.299) + (s_c1 * 0.587)    + (s_c2 * 0.114);
        *(s_1) = (s_c0 * 0.596) + (s_c1 * (-0.275)) + (s_c2 * 0.321); 
        *(s_2) = (s_c0 * 0.212) + (s_c1 * (-0.523)) + (s_c2 * 0.311);
       }
       break;
  case E_JPEG_RGB2YIQ:
       if(s_0 && s_1 && s_2)
       {
        t_float s_c0, s_c1, s_c2;
        s_c0 = *(s_0); s_c1 = *(s_1); s_c2 = *(s_2); 
        *(s_0) = (s_c0 / 0.299) + (s_c1 / 0.587)    + (s_c2 / 0.114);
        *(s_1) = (s_c0 / 0.596) + (s_c1 / (-0.275)) + (s_c2 / 0.321); 
        *(s_2) = (s_c0 / 0.212) + (s_c1 / (-0.523)) + (s_c2 / 0.311);
       }
       break;  
  case E_JPEG_RGB2INDEX556: // REG(5) / GREEN(5) / BLUE(6) format   - ��� Frame buffer������ �̰�
       if(s_0 && s_1 && s_2 && s_Index)
       {
        *(s_Index) = ((int)(((int)*(s_0))<<11) | (int)(((int)*(s_1))<<6) | (int)((int)*(s_2)));
       } 
       break;
  case E_JPEG_RGB2INDEX565: // REG(5) / GREEN(6) / BLUE(5) format   - �̰͵� ���� ��������� 
       if(s_0 && s_1 && s_2 && s_Index)
       {
        *(s_Index) = ((int)(((int)*(s_0))<<11) | (int)(((int)*(s_1))<<5) | (int)((int)*(s_2)));
       } 
       break;
  case E_JPEG_RGB2INDEX655: // REG(6) / GREEN(5) / BLUE(5) format  
       if(s_0 && s_1 && s_2 && s_Index)
       {
        *(s_Index) = ((int)(((int)*(s_0))<<10) | (int)(((int)*(s_1))<<5) | (int)((int)*(s_2)));
       } 
       break;
  default: fprintf(stderr, "MZ_JPEG: Invalid convert color!!!\n"); break;
 }    
}

inline t_byte _JPEG_GetEmitByte(t_void *s_Ptr, t_int s_Entry)
{
 return(*(((t_byte *)s_Ptr)+s_Entry));   
}

inline t_word _JPEG_GetEmitWord(t_void *s_Ptr, t_int s_Entry)
{
 return((((t_word)(*(((t_byte *)s_Ptr)+s_Entry)))<<8)|((t_word)(*(((t_byte *)s_Ptr)+s_Entry+1))));    
}

#if DEF_JPEG_CHECK == 1
t_void __DumpImage(t_void *s_DumpImage, t_ulong s_Size)
{ // ��¥ ������ Ȯ���Ҷ��~
 t_ulong s_Offset = (t_ulong)0, s_LF;
 t_byte  s_ASCII[16 + 1]; 
 while(s_Offset < s_Size)
 {
  memset(s_ASCII, 0, 16 + 1);   
  fprintf(stdout, "                           %08lX ", s_Offset);
  for(s_LF = 0;s_LF < 16 && s_Offset < s_Size;s_LF++, s_Offset++)
  {   
   s_ASCII[s_LF] = *((t_byte *)s_DumpImage);   
   if(s_ASCII[s_LF] < 0x20 || s_ASCII[s_LF] > 127)s_ASCII[s_LF] = '.';
   if(s_LF == 8)fprintf(stdout, ": "); 
   fprintf(stdout, "%02X ", ((t_int)(*((t_byte *)s_DumpImage)))&0xff); 
   ((t_byte *)s_DumpImage)++; 
  }
  if(s_LF != 16)fprintf(stdout, "\n");
  if((s_Offset % 16) == (t_ulong)0)fprintf(stdout, "%s - %lu\n", s_ASCII, s_Offset);
 } 
}

t_void __DumpImage8(t_void *s_DumpImage, t_ulong s_Size)
{ // ��¥ ������ Ȯ���Ҷ��~
 t_ulong s_Offset = (t_ulong)0, s_LF;
 t_byte  s_ASCII[8 + 1]; 
 while(s_Offset < s_Size)
 {
  memset(s_ASCII, 0, 8 + 1);   
  fprintf(stdout, "                           %08lX ", s_Offset);
  for(s_LF = 0;s_LF < 8 && s_Offset < s_Size;s_LF++, s_Offset++)
  {   
   s_ASCII[s_LF] = *((t_byte *)s_DumpImage);   
   if(s_ASCII[s_LF] < 0x20 || s_ASCII[s_LF] > 127)s_ASCII[s_LF] = '.';
   fprintf(stdout, "%02X ", ((t_int)(*((t_byte *)s_DumpImage)))&0xff); 
   ((t_byte *)s_DumpImage)++; 
  }
  if(s_LF != 8)fprintf(stdout, "\n");
  if((s_Offset % 8) == (t_ulong)0)fprintf(stdout, "%s - %lu\n", s_ASCII, s_Offset);
 } 
}


t_void __ReportPacket(t_word s_Marker, t_void *s_DumpImage, t_word s_Size, t_ulong s_Start, t_ulong s_End)
{ // ������ Ȯ���Ҷ��~
 t_int s_Count = (t_int)0;
 t_char *s_NameTable = "------";	
 if(s_Count);
 switch(s_Marker)
 {
  case E_JPEG_SOI:   s_NameTable = "[OK] SOI (Start of image)";   break;	  
  case E_JPEG_SOS:   s_NameTable = "[OK] SOS (Start of scan)";   break;	  
  case E_JPEG_EOI:   s_NameTable = "[OK] EOI (End of image)";   break;	  
  case E_JPEG_SOF0:  s_NameTable = "[OK] SOF0 (Baseline DCT)";  break;	  
  case E_JPEG_SOF1:  s_NameTable = "SOF1";  break;	  
  case E_JPEG_SOF2:  s_NameTable = "[OK] SOF2";  break;	  
  case E_JPEG_SOF3:  s_NameTable = "SOF3";  break;	  
  case E_JPEG_SOF4:  s_NameTable = "SOF4";  break;	  
  case E_JPEG_SOF5:  s_NameTable = "SOF5";  break;	  
  case E_JPEG_SOF6:  s_NameTable = "SOF6";  break;	  
  case E_JPEG_SOF7:  s_NameTable = "SOF7";  break;	  
  // case E_JPEG_SOF8:  s_NameTable = "SOF8";  break;	  
  case E_JPEG_SOF9:  s_NameTable = "SOF9";  break;	  
  case E_JPEG_SOF10: s_NameTable = "SOF10"; break;	  
  // case E_JPEG_SOF11: s_NameTable = "SOF11"; break;	  
  // case E_JPEG_SOF12: s_NameTable = "SOF12"; break;	  
  case E_JPEG_SOF13: s_NameTable = "SOF13"; break;	  
  case E_JPEG_SOF14: s_NameTable = "SOF14"; break;	  
  case E_JPEG_SOF15: s_NameTable = "SOF15"; break;	  
  case E_JPEG_DHT:   s_NameTable = "[OK] DHT";   break;	  
  case E_JPEG_DAC:   s_NameTable = "DAC";   break;	  
  case E_JPEG_RST0:  s_NameTable = "RST0";  break;	  
  case E_JPEG_RST1:  s_NameTable = "RST1";  break;	  
  case E_JPEG_RST2:  s_NameTable = "RST2";  break;	  
  case E_JPEG_RST3:  s_NameTable = "RST3";  break;	  
  case E_JPEG_RST4:  s_NameTable = "RST4";  break;	  
  case E_JPEG_RST5:  s_NameTable = "RST5";  break;	  
  case E_JPEG_RST6:  s_NameTable = "RST6";  break;	  
  case E_JPEG_RST7:  s_NameTable = "RST7";  break;	  
  case E_JPEG_DQT:   s_NameTable = "[OK] DQT";   break;	  
  case E_JPEG_DNL:   s_NameTable = "DNL";   break;	  
  case E_JPEG_DRI:   s_NameTable = "DRI";   break;	  
  case E_JPEG_DHP:   s_NameTable = "DHP";   break;	  
  case E_JPEG_EXP:   s_NameTable = "EXP";   break;	  
  case E_JPEG_APP0:  s_NameTable = "[CANCEL] APP0 (Adobe)";  break;	  
  case E_JPEG_APP1:  s_NameTable = "[CANCEL] APP1";  break;	  
  case E_JPEG_APP2:  s_NameTable = "[CANCEL] APP2";  break;	  
  case E_JPEG_APP3:  s_NameTable = "[CANCEL] APP3";  break;	  
  case E_JPEG_APP4:  s_NameTable = "[CANCEL] APP4";  break;	  
  case E_JPEG_APP5:  s_NameTable = "[CANCEL] APP5";  break;	  
  case E_JPEG_APP6:  s_NameTable = "[CANCEL] APP6";  break;	  
  case E_JPEG_APP7:  s_NameTable = "[CANCEL] APP7";  break;	  
  case E_JPEG_APP8:  s_NameTable = "[CANCEL] APP8";  break;	  
  case E_JPEG_APP9:  s_NameTable = "[CANCEL] APP9";  break;	  
  case E_JPEG_APP10: s_NameTable = "[CANCEL] APP10"; break;	  
  case E_JPEG_APP11: s_NameTable = "[CANCEL] APP11"; break;	  
  case E_JPEG_APP12: s_NameTable = "[CANCEL] APP12"; break;	  
  case E_JPEG_APP13: s_NameTable = "[CANCEL] APP13"; break;	  
  case E_JPEG_APP14: s_NameTable = "[CANCEL] APP14"; break;	  
  case E_JPEG_APP15: s_NameTable = "[CANCEL] APP15"; break;	  
  // case E_JPEG_JPG0:  s_NameTable = "JPG0";  break;	  
  // case E_JPEG_JPG13: s_NameTable = "JPG13"; break;	  
  case E_JPEG_COM:   s_NameTable = "COM";   break;	  
  case E_JPEG_TEM:   s_NameTable = "TEM";   break;	  
  default: break;	 
 } 
 fprintf(stdout, "MZ_JPEG: Marker=0xff%02X, Size=%-8u, Start=%-8lu, End=%-8lu \"%s\"\n", s_Marker, s_Size, s_Start, s_End, s_NameTable);
 if(s_Marker == E_JPEG_SOF0 || s_Marker == E_JPEG_SOF2)
 { 
  fprintf(stdout, "MZ_JPEG: [Frame header %02X] Size = 0x%04X\n", s_Marker, _JPEG_GetEmitWord(s_DumpImage, 0));
  fprintf(stdout, "                   ������ ������ ����ȭ ��Ʈ��           /1/     = 0x%02X\n" , _JPEG_GetEmitByte(s_DumpImage, 2));
  fprintf(stdout, "                   ������ ũ��                           /2 + 2/ = %u x %u\n", _JPEG_GetEmitWord(s_DumpImage, 5), _JPEG_GetEmitWord(s_DumpImage, 3));
  fprintf(stdout, "                   �������� �����ϴ� ������Ʈ�� ��       /1/     = 0x%02X\n" , _JPEG_GetEmitByte(s_DumpImage, 7));
  for(s_Count = 0;s_Count < _JPEG_GetEmitByte(s_DumpImage, 7);s_Count++)
  {
   fprintf(stdout, "                           ������Ʈ: ��ȣ               /1/   = 0x%02X\n" , _JPEG_GetEmitByte(s_DumpImage, 8 + (3 * s_Count)));
   fprintf(stdout, "                                     ���� ���ø� ����   /0.5/ = 0x%02X\n" , (_JPEG_GetEmitByte(s_DumpImage, 9 + (3 * s_Count)))>>4 & 0x0f);
   fprintf(stdout, "                                     ���� ���ø� ����   /0.5/ = 0x%02X\n" , (_JPEG_GetEmitByte(s_DumpImage, 9 + (3 * s_Count))) & 0x0f);
   fprintf(stdout, "                                     ����ȭ ���̺� ��ȣ /1/   = 0x%02X\n" , (_JPEG_GetEmitByte(s_DumpImage, 10 + (3 * s_Count))));
  }
 }
 if(s_Marker == E_JPEG_SOS)
 {
  fprintf(stdout, "MZ_JPEG: [Scan header %02X] Size = 0x%04X\n", s_Marker, _JPEG_GetEmitWord(s_DumpImage, 0));
  fprintf(stdout, "                   ��ĵ ������Ʈ �� /1/                       = 0x%02X\n" , _JPEG_GetEmitByte(s_DumpImage, 2));
  for(s_Count = 0;s_Count < _JPEG_GetEmitByte(s_DumpImage, 2);s_Count++)
  {
   fprintf(stdout, "                           ������Ʈ ��ȣ                     /1/   = 0x%02X\n" , _JPEG_GetEmitByte(s_DumpImage, 3 + (2 * s_Count)));
   fprintf(stdout, "                           DC ��� ��Ʈ���� ��ȣ ���̺� ��ȣ /0.5/ = 0x%02X\n" , (_JPEG_GetEmitByte(s_DumpImage, 4 + (2 * s_Count)))>>4 & 0x0f);
   fprintf(stdout, "                           AC ��� ��Ʈ���� ��ȣ ���̺� ��ȣ /0.5/ = 0x%02X\n" , (_JPEG_GetEmitByte(s_DumpImage, 4 + (2 * s_Count))) & 0x0f);
  }
  fprintf(stdout, "                   ����Ʈ�� ���ù���� ����       /1/         = 0x%02X\n" , _JPEG_GetEmitByte(s_DumpImage, 5 + (2 * s_Count)));
  fprintf(stdout, "                   ����Ʈ�� ���ù���� ����       /1/         = 0x%02X\n" , _JPEG_GetEmitByte(s_DumpImage, 6 + (2 * s_Count)));
  fprintf(stdout, "                   ���� �ٻ� ��Ľ� ��Ʈ��ġ ���� /0.5/       = 0x%02X\n" , (_JPEG_GetEmitByte(s_DumpImage, (7 + (2 * s_Count))))>>4 & 0x0f);
  fprintf(stdout, "                   ���� �ٻ� ��Ľ� ��Ʈ��ġ ���� /0.5/       = 0x%02X\n" , (_JPEG_GetEmitByte(s_DumpImage, (7 + (2 * s_Count)))) & 0x0f);
 }
 if(s_Marker == E_JPEG_DHT)
 {
  t_int s_Sum = (t_int)0;   
  fprintf(stdout, "MZ_JPEG: [Huffman table header %02X] Size = 0x%04X\n", s_Marker, _JPEG_GetEmitWord(s_DumpImage, 0));
  fprintf(stdout, "                   ������ ���̺� ��ȣ /1/                     = 0x%02X\n" , _JPEG_GetEmitByte(s_DumpImage, 2));
  for(s_Count = 0;s_Count < 16;s_Count++)
  {
   s_Sum += _JPEG_GetEmitByte(s_DumpImage, 3 + s_Count);	  
   if(_JPEG_GetEmitByte(s_DumpImage, 3 + s_Count))fprintf(stdout, "                           ������ ��ȣ ���� /1/ [Index:0x%02X] : %d ����ġ=%d\n", s_Count, _JPEG_GetEmitByte(s_DumpImage, 3 + s_Count), s_Sum);
  }
  fprintf(stdout, "                           ������ ��ȣ /%d/ ---------------------------\n", s_Sum);
  // ������ ��ȣ���� 16���� �����Ͽ� �׸�ŭ�� ���̺��� �ִ�.
  __DumpImage(((t_byte *)s_DumpImage) + 3 + 16, s_Sum);
 }
 if(s_Marker == E_JPEG_DQT)
 {
  t_byte s_BitType = (_JPEG_GetEmitByte(s_DumpImage, 2))>>4 & 0x0f;   
  fprintf(stdout, "MZ_JPEG: [����ȭ table header %02X] Size = 0x%04X\n", s_Marker, _JPEG_GetEmitWord(s_DumpImage, 0));
  fprintf(stdout, "                   ����ȭ ��Ʈ�� ���� /0.5/                   = 0x%02X (%s)\n" , s_BitType, ((s_BitType==0)?"8��Ʈ":"16��Ʈ"));
  fprintf(stdout, "                   ����ȭ ���̺� ��ȣ /0.5/                   = 0x%02X\n" , (_JPEG_GetEmitByte(s_DumpImage, 2)) & 0x0f );
  fprintf(stdout, "                           ����ȭ ���̺� /64/ ---------------------------\n");
  __DumpImage8(((t_byte *)s_DumpImage) + 3, 64);
 }
 if(s_Marker == E_JPEG_DRI)
 {
  fprintf(stdout, "MZ_JPEG: [DRI interval %02X] Size = 0x%04X\n", s_Marker, _JPEG_GetEmitWord(s_DumpImage, 0));
  fprintf(stdout, "                   Define restart interval /2/                = 0x%04X\n" , _JPEG_GetEmitWord(s_DumpImage, 2));
 }

}
#endif

t_JPEG_Node *JPEG_Node(t_JPEG_Node *s_JPEG_Node, t_void *s_DumpImage, t_ulong s_Start, t_ulong s_End)
{ // ������ Marker���� �а� ������ ���Ḯ��Ʈ�� �����մϴ�.
 t_byte       s_Marker[2];   
 t_word       s_Size           = 0;
 t_JPEG_Node *s_Return         = (t_JPEG_Node *)0;
 t_int        s_AppendSOS      = 0;
 if(s_DumpImage == (t_void *)0 || s_Start >= s_End)return(s_Return); 
 while(s_Start < s_End)
 {
  s_Marker[0] = *(((t_byte *)s_DumpImage)++); s_Start++;
  if(s_Marker[0] == 0xff)
  {
   s_Marker[1] = *(((t_byte *)s_DumpImage)++); s_Start++;
   if((s_Marker[1]&0xc0) == 0xc0)
   {
    if(s_Marker[1] == E_JPEG_SOI || s_Marker[1] == E_JPEG_EOI)s_Size = (t_ulong)0;   
    else s_Size = _JPEG_GetEmitWord(s_DumpImage, 0);
    #if DEF_JPEG_CHECK == 1
    __ReportPacket(s_Marker[1], s_DumpImage, s_Size, s_Start, s_End);  
    #endif
    if(s_Marker[1] == E_JPEG_SOS)s_AppendSOS++; 
    if(s_Marker[1] == E_JPEG_SOI || s_Marker[1] == E_JPEG_EOI)
    {
     if(s_Marker[1] != E_JPEG_EOI)
     {
      t_JPEG_Node *s_JPEG_Node_Next = JPEG_Node(s_JPEG_Node, s_DumpImage, s_Start, s_End); 
      if(s_JPEG_Node && s_JPEG_Node_Next)s_JPEG_Node->Next = s_JPEG_Node_Next;	  
     }
     else
     {
      #if DEF_JPEG_CHECK == 1
       fprintf(stdout, "MZ_JPEG: Maximum memory = %lu\n", JPEG_ReportMemory());
      #endif 
     }
     break;
    }
    ((t_byte *)s_DumpImage) += s_Size; s_Start += s_Size;
   }
   else if(s_Marker[1] == 0x00 || s_Marker[1] == 0xff)
   {
    ((t_byte *)s_DumpImage) += s_Size; s_Start += s_Size;
   }
   else 
   {
    fprintf(stderr, "!!! MZ_JPEG: Invalid Jpeg format!!! Skip Marker=0x%02X%02X, Size=%u\n", s_Marker[0], s_Marker[1], s_Size);
    break;
   }
  }
  else if(s_AppendSOS == 0) // SOS ���Ĵ� MCU �̱� ������ ���� ��
  {
   fprintf(stdout, "!!! MZ_JPEG: Invalid Jpeg format!!! Skip Marker=0x%02X%02X, Size=%u\n", s_Marker[0], s_Marker[1], s_Size);
   break;
  }
 }
 return(s_Return); 
}

#endif                                           /* DEF_jpeg_c                  */

/* End of source */
