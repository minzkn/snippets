/*
 Title                               : gdc.c                                   MZLIB 
 MZLIB Source by                     : Jae Hyuk CHO                            �� �� �� [011-9702-2744] 
 Copyright                           : Information Equipment co.,LTD.          (��) ������ť 
 Licence                             : GPL licence

 !RAW!
  DEF_ : Define
  t_   : typedef
  tx_  : typedef first field type - `x'    ( Ex: typedef enum -> typedef enum te_Bool{.......}t_Bool; )
  g_   : Global
  s_   : Local
  c_   : Const

 E-Mail : minzkn@dreamwiz.com
          minzkn@infoeq.com
	  minzkn@infoeq.co.kr

 Test environment : RedHat 7.1 (k)
                    Wow linux paran 7.1
	 
 Graphic accelator engine by JaeHyuk algorithm ^^;	  
*/

#ifndef DEF_gdc_c                    /* Already include ??? */
#define DEF_gdc_c                    "gdc.c"  

#define DEF_DEBUG_GDC                0 
// #define DEF_DEBUG_GDC                1

#ifndef DEF_USE_JPEGLIB 
#define DEF_USE_JPEGLIB              0
/*
#define DEF_USE_JPEGLIB              1
*/
#endif

#define DEF_USE_JPEGBUFFER           1

#ifndef DEF_USE_GIFLIB    
#define DEF_USE_GIFLIB               0
/*
#defien DEF_USE_GIFLIB               1
*/
#endif

#ifndef DEF_USE_AUTOINIT
/* 
#define DEF_USE_AUTOINIT             0
*/
#define DEF_USE_AUTOINIT             1
#endif

#ifndef DEF_USE_RY_TYPE 
/*
#define DEF_USE_RY_TYPE              0
*/
#define DEF_USE_RY_TYPE              1
#endif

#ifndef DEF_USE_DRAWMODE    
#define DEF_USE_DRAW_TYPE            0  /* 0=RGB to RGB, 1=RGB to YCbCr(Virtual) */   
#endif

#ifndef DEF_USE_GDC_SHARED        
#define DEF_USE_GDC_SHARED           0 /* Not yet !!! Can not support - �����ȵ�. ������ �Ӹ������� ����. */
#endif

#include                             <stdio.h>
#include                             <unistd.h>
#include                             <fcntl.h>
#include                             <stdarg.h>
#include                             <string.h>
#include                             <stdlib.h>
#include                             <memory.h>
#include                             <sys/mman.h>
#include                             <sys/ioctl.h>
#include                             <sys/types.h>
#include                             <sys/stat.h>
#include                             <termios.h>
#include                             <sys/kd.h>
#include                             <sys/vt.h>
#include                             <malloc.h>
#include                             <sys/timeb.h>

#if DEF_USE_JPEGLIB == 1
 #include                             <jpeglib.h>
#endif

#if DEF_USE_GIFLIB == 1
 #include                             <gif_lib.h>
#endif

#include                             "gdc.h"

#if DEF_USE_AUTOINIT == 1
#define DEF_GDC_AUTOINIT()           if(s_HANDLE_GDC == (t_GDC *)0)\
                                     {\
                                      if(g_GDC_Main == (t_GDC *)0)g_GDC_Main = OpenGDC((void *)0, (-1), (-1), (-1));\
	                              s_HANDLE_GDC = g_GDC_Main;\
				     }   
#else
#define DEF_GDC_AUTOINIT()           if(s_HANDLE_GDC == (t_GDC *)0)return; 				     
#endif
				     
extern unsigned char g_Font08[], g_Font16[]; /* Bitmap font 8x16 & 16x16 */ 

t_GDC *OpenGDC(char *s_DeviceName, int s_ResX, int s_ResY, int s_ResBytes);
t_GDC *CloseGDC(t_GDC *s_HANDLE_GDC);
inline int __GDC_Check(t_GDC *s_HANDLE_GDC, int s_x, int s_y);
inline void __GDC_CheckSwap(int *s_Min, int *s_Max);
inline void __GDC_CheckLimitX(t_GDC *s_HANDLE_GDC, int *s_x);
inline void __GDC_CheckLimitY(t_GDC *s_HANDLE_GDC, int *s_y);
int __GDC_GetPixel_01(t_GDC *s_HANDLE_GDC, int s_x, int s_y);
int __GDC_GetPixel_02(t_GDC *s_HANDLE_GDC, int s_x, int s_y);
int __GDC_GetPixel_03(t_GDC *s_HANDLE_GDC, int s_x, int s_y);
int __GDC_GetPixel_04(t_GDC *s_HANDLE_GDC, int s_x, int s_y);
inline int GDC_GetPixel(t_GDC *s_HANDLE_GDC, int s_x, int s_y);
void __GDC_SetPixel_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y);
void __GDC_SetPixel_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y);
void __GDC_SetPixel_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y);
void __GDC_SetPixel_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y);
inline void GDC_SetPixel(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y);
inline void GDC_DrawPixel(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y);
void __GDC_GetHLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
void __GDC_GetHLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
void __GDC_GetHLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
void __GDC_GetHLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
inline void GDC_GetHLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
void __GDC_SetHLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
void __GDC_SetHLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
void __GDC_SetHLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
void __GDC_SetHLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
inline void GDC_SetHLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
void __GDC_DrawHLine_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
void __GDC_DrawHLine_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
void __GDC_DrawHLine_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
void __GDC_DrawHLine_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
inline void GDC_DrawHLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
void __GDC_XORHLine_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
void __GDC_XORHLine_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
void __GDC_XORHLine_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
void __GDC_XORHLine_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
inline void GDC_XORHLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
void __GDC_GetVLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
void __GDC_GetVLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
void __GDC_GetVLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
void __GDC_GetVLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
inline void GDC_GetVLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
void __GDC_SetVLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
void __GDC_SetVLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
void __GDC_SetVLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
void __GDC_SetVLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
inline void GDC_SetVLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
void __GDC_DrawVLine_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
void __GDC_DrawVLine_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
void __GDC_DrawVLine_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
void __GDC_DrawVLine_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
inline void GDC_DrawVLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
void __GDC_XORVLine_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
void __GDC_XORVLine_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
void __GDC_XORVLine_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
void __GDC_XORVLine_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
inline void GDC_XORVLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
void __GDC_GetBox_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_GetBox_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_GetBox_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_GetBox_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
inline void GDC_GetBox(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_SetBox_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_SetBox_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_SetBox_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_SetBox_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
inline void GDC_SetBox(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_DrawBox_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_DrawBox_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_DrawBox_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_DrawBox_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
inline void GDC_DrawBox(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_XORBox_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_XORBox_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_XORBox_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
void __GDC_XORBox_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
inline void GDC_DrawBox(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
void *__GDC_GetLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
void *__GDC_GetLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
void *__GDC_GetLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
void *__GDC_GetLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
void GDC_GetLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
void *__GDC_SetLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
void *__GDC_SetLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
void *__GDC_SetLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
void *__GDC_SetLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
void GDC_SetLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
void GDC_DrawLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
inline void GDC_Bitmap8x16(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_Color, int s_BackColor, int s_x, int s_y);
inline void GDC_Bitmap16x16(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_Color, int s_BackColor, int s_x, int s_y);
inline void GDC_DrawEnglish(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, int s_Character, int s_x, int s_y);
void GDC_DrawHangul(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, int s_Character, int s_x, int s_y);
inline void GDC_GetFontSize(t_GDC *s_HANDLE_GDC, int *s_SizeX, int *s_SizeY);
inline void GDC_SetFontSize(t_GDC *s_HANDLE_GDC, int s_SizeX, int s_SizeY);
inline void GDC_ClearScreen(t_GDC *s_HANDLE_GDC, int s_Color);
inline void GDC_ConvertKStoJO(unsigned short *s_HangulCode);
void GDC_DrawPutsEnglish(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, void *s_String, int s_x, int s_y);
void GDC_DrawPutsHangul(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, void *s_String, int s_x, int s_y);
void GDC_DrawPrintfEnglish(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, int s_x, int s_y, void *s_FormatString, ...);
void GDC_DrawPrintfHangul(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, int s_x, int s_y, void *s_FormatString, ...);
inline void GDC_DrawRec3D(t_GDC *s_HANDLE_GDC, int s_LColor, int s_RColor, int s_x1, int s_y1, int s_x2, int s_y2);
void GDC_DrawRectangle(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
void GDC_DrawBox3D(t_GDC *s_HANDLE_GDC, int s_LColor, int s_RColor, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
int GDC_Color(int s_Red, int s_Green, int s_Blue);
int GDC_Color64(int s_Red, int s_Green, int s_Blue);
int GDC_Color256(int s_Red, int s_Green, int s_Blue);
void GDC_DrawButton(t_GDC *s_HANDLE_GDC, int s_Switch, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
int GDC_OpenMouse(t_GDC *s_HANDLE_GDC, void (*s_MouseEvent)(struct ts_GDC *));
void GDC_CloseMouse(t_GDC *s_HANDLE_GDC);
int __GDC_GetMouse(t_GDC *s_HANDLE_GDC, int *s_x, int *s_y, int *s_Button);
void GDC_MouseCursor(t_GDC *s_HANDLE_GDC, int s_Type);
void GDC_MouseProcess(t_GDC *s_HANDLE_GDC);
int GDC_MouseArea(t_GDC *s_HANDLE_GDC, int s_x1, int s_y1, int s_x2, int s_y2);
int GDC_LoadJpeg(t_GDC *s_HANDLE_GDC, void *s_JpegName, int s_x, int s_y);
int GDC_LoadGif(t_GDC *s_HANDLE_GDC, void *s_GifName, int s_x, int s_y);
int GDC_Percent(int s_SMin, int s_SMax, int s_Current, int s_TMin, int s_TMax);
void GDC_UpdateBox(t_GDC *s_HANDLE_GDC, void *s_Source, void *s_Target, int s_x1, int s_y1, int s_x2, int s_y2);
void GDC_Scroll(t_GDC *s_HANDLE_GDC, int s_Arrow, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2, int s_Grid);
t_HANDLE_Keyboard *MZKEY_OPEN(const char *s_KeyboardDevice);
t_HANDLE_Keyboard *MZKEY_CLOSE(t_HANDLE_Keyboard *s_HANDLE_Keyboard);
int MZKEY_PROCESS(t_HANDLE_Keyboard *s_HANDLE_Keyboard);
int MZKEY_READKEY(t_HANDLE_Keyboard *s_HANDLE_Keyboard);
t_HANDLE_Keyboard *GDC_OpenKeyboard(t_GDC *s_HANDLE_GDC, char *s_DeviceName);
int GDC_KeyboardProcess(t_GDC *s_HANDLE_GDC);
int GDC_GetKey(t_GDC *s_HANDLE_GDC);
void GDC_CloseKeyboard(t_GDC *s_HANDLE_GDC);
void GDC_Blender16(t_GDC *s_GDC, unsigned int s_AlphaR, unsigned int s_AlphaG, unsigned int s_AlphaB, int s_x1, int s_y1, int s_x2, int s_y2);
void RGB_YCbCr(int s_Red, int s_Green, int s_Blue, int *s_Y, int *s_Cb, int *s_Cr);
void YCbCr_RGB(int s_Y, int s_Cb, int s_Cr, int *s_Red, int *s_Green, int *s_Blue);
void PPC_DrawPixel(t_GDC *s_GDC, void *s_MemMap, int s_Red, int s_Green, int s_Blue, int s_x, int s_y);
void PPC_DrawBox(t_GDC *s_GDC, void *s_MemMap, int s_Red, int s_Green, int s_Blue, int s_x1, int s_y1, int s_x2, int s_y2);
void PPC_DrawHLine(t_GDC *s_GDC, void *s_MemMap, int s_Red, int s_Green, int s_Blue, int s_x1, int s_x2, int s_y);
void PPC_DrawVLine(t_GDC *s_GDC, void *s_MemMap, int s_Red, int s_Green, int s_Blue, int s_x, int s_y1, int s_y2);

int (*_GDC_GetPixel[])(t_GDC *, int, int) = {                             /* GDC_GetPixel */
     __GDC_GetPixel_01, __GDC_GetPixel_02, __GDC_GetPixel_03, __GDC_GetPixel_04
    };
    
void (*_GDC_SetPixel[])(t_GDC *, int, int, int) = {                       /* GDC_SetPixel, GDC_DrawPixel */
      __GDC_SetPixel_01, __GDC_SetPixel_02, __GDC_SetPixel_03, __GDC_SetPixel_04
     };   
    
void (*_GDC_GetHLine[])(t_GDC *, void *, int, int, int) = {               /* GDC_GetHLine */
      __GDC_GetHLine_01, __GDC_GetHLine_02, __GDC_GetHLine_03, __GDC_GetHLine_04
     };    

void (*_GDC_SetHLine[])(t_GDC *, void *, int, int, int) = {               /* GDC_SetHLine */
      __GDC_SetHLine_01, __GDC_SetHLine_02, __GDC_SetHLine_03, __GDC_SetHLine_04
     };    
 
void (*_GDC_DrawHLine[])(t_GDC *, int, int, int, int) = {                 /* GDC_DrawHLine */
      __GDC_DrawHLine_01, __GDC_DrawHLine_02, __GDC_DrawHLine_03, __GDC_DrawHLine_04
     }; 
    
void (*_GDC_XORHLine[])(t_GDC *, int, int, int, int) = {                 /* GDC_XORHLine */
      __GDC_XORHLine_01, __GDC_XORHLine_02, __GDC_XORHLine_03, __GDC_XORHLine_04
     }; 
    
void (*_GDC_GetVLine[])(t_GDC *, void *, int, int, int) = {              /* GDC_GetVLine */
      __GDC_GetVLine_01, __GDC_GetVLine_02, __GDC_GetVLine_03, __GDC_GetVLine_04
     };    
    
void (*_GDC_SetVLine[])(t_GDC *, void *, int, int, int) = {              /* GDC_SetVLine */
      __GDC_SetVLine_01, __GDC_SetVLine_02, __GDC_SetVLine_03, __GDC_SetVLine_04
     };    
    
void (*_GDC_DrawVLine[])(t_GDC *, int, int, int, int) = {                /* GDC_DrawVLine */
      __GDC_DrawVLine_01, __GDC_DrawVLine_02, __GDC_DrawVLine_03, __GDC_DrawVLine_04
     };    
    
void (*_GDC_XORVLine[])(t_GDC *, int, int, int, int) = {                /* GDC_XORVLine */
      __GDC_XORVLine_01, __GDC_XORVLine_02, __GDC_XORVLine_03, __GDC_XORVLine_04
     };    
    
void (*_GDC_GetBox[])(t_GDC *, void *, int, int, int, int) = {           /* GDC_GetBox */
      __GDC_GetBox_01, __GDC_GetBox_02, __GDC_GetBox_03, __GDC_GetBox_04
     };    
    
void (*_GDC_SetBox[])(t_GDC *, void *, int, int, int, int) = {           /* GDC_SetBox */
      __GDC_SetBox_01, __GDC_SetBox_02, __GDC_SetBox_03, __GDC_SetBox_04
     };    
   
void (*_GDC_DrawBox[])(t_GDC *, int, int, int, int, int) = {             /* GDC_DrawBox */
      __GDC_DrawBox_01, __GDC_DrawBox_02, __GDC_DrawBox_03, __GDC_DrawBox_04
     };   
  
void (*_GDC_XORBox[])(t_GDC *, int, int, int, int, int) = {             /* GDC_XORBox */
      __GDC_XORBox_01, __GDC_XORBox_02, __GDC_XORBox_03, __GDC_XORBox_04
     };   
  
void *(*_GDC_GetLine[])(t_GDC *, void *, int, int) = {                   /* GDC_GetLine */
      __GDC_GetLine_01, __GDC_GetLine_02, __GDC_GetLine_03, __GDC_GetLine_04
     };  

void *(*_GDC_SetLine[])(t_GDC *, void *, int, int) = {                   /* GDC_SetLine */
      __GDC_SetLine_01, __GDC_SetLine_02, __GDC_SetLine_03, __GDC_SetLine_04
     };  
     
/*
 3���� �ѱ� ������ ���� Table - �ڵ�� ó���Ҽ� ������ �ӵ��� �޸� ũ�⸦ �����غ��� ���̺��� ������ ũ��.
*/
unsigned char g_HAN_table0[32U] ={0x07, 0xff, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 
				  0x10, 0x11, 0x12, 0xff, 0x09, 0x0b, 0x0b, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
unsigned char g_HAN_table1[32U] ={0xff, 0xff, 0xff, 0x00, 0x01, 0x02, 0x03, 0x04, 0xff, 0xff, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0xff, 0xff, 
				  0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0xff, 0xff, 0x11, 0x12, 0x13, 0x14, 0x00, 0x01}; 
unsigned char g_HAN_table2[32U] ={0xff, 0xff, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 
				  0xff, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x14, 0x14};
unsigned char g_HAN_ftable0[21U]={0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x03, 0x03, 0x03, 0x01, 0x02, 0x04, 0x04, 0x04, 0x02, 
				  0x01, 0x03, 0x00}; 
unsigned char g_HAN_ftable1[21U]={0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x06, 0x07, 0x07, 0x07, 0x06, 0x06, 0x07, 0x07, 0x07, 0x06, 
				  0x06, 0x07, 0x05};
unsigned char g_HAN_ltable[21U] ={0x00, 0x02, 0x00, 0x02, 0x01, 0x02, 0x01, 0x02, 0x03, 0x00, 0x02, 0x01, 0x03, 0x03, 0x01, 0x02, 0x01, 0x03, 
				  0x03, 0x01, 0x01}; 

unsigned short g_HAN_KSTable[2350] = {
   0x8861,0x8862,0x8865,0x8868,0x8869,0x886A,0x886B,0x8871, 0x8873,0x8874,0x8875,0x8876,0x8877,0x8878,0x8879,0x887B,
   0x887C,0x887D,0x8881,0x8882,0x8885,0x8889,0x8891,0x8893, 0x8895,0x8896,0x8897,0x88A1,0x88A2,0x88A5,0x88A9,0x88B5,
   0x88B7,0x88C1,0x88C5,0x88C9,0x88E1,0x88E2,0x88E5,0x88E8, 0x88E9,0x88EB,0x88F1,0x88F3,0x88F5,0x88F6,0x88F7,0x88F8,
   0x88FB,0x88FC,0x88FD,0x8941,0x8945,0x8949,0x8951,0x8953, 0x8955,0x8956,0x8957,0x8961,0x8962,0x8963,0x8965,0x8968,
   0x8969,0x8971,0x8973,0x8975,0x8976,0x8977,0x897B,0x8981, 0x8985,0x8989,0x8993,0x8995,0x89A1,0x89A2,0x89A5,0x89A8,
   0x89A9,0x89AB,0x89AD,0x89B0,0x89B1,0x89B3,0x89B5,0x89B7, 0x89B8,0x89C1,0x89C2,0x89C5,0x89C9,0x89CB,

   0x89D1,0x89D3,0x89D5,0x89D7,0x89E1,0x89E5,0x89E9,0x89F1, 0x89F6,0x89F7,0x8A41,0x8A42,0x8A45,0x8A49,0x8A51,0x8A53,
   0x8A55,0x8A57,0x8A61,0x8A65,0x8A69,0x8A73,0x8A75,0x8A81, 0x8A82,0x8A85,0x8A88,0x8A89,0x8A8A,0x8A8B,0x8A90,0x8A91,
   0x8A93,0x8A95,0x8A97,0x8A98,0x8AA1,0x8AA2,0x8AA5,0x8AA9, 0x8AB6,0x8AB7,0x8AC1,0x8AD5,0x8AE1,0x8AE2,0x8AE5,0x8AE9,
   0x8AF1,0x8AF3,0x8AF5,0x8B41,0x8B45,0x8B49,0x8B61,0x8B62, 0x8B65,0x8B68,0x8B69,0x8B6A,0x8B71,0x8B73,0x8B75,0x8B77,
   0x8B81,0x8BA1,0x8BA2,0x8BA5,0x8BA8,0x8BA9,0x8BAB,0x8BB1, 0x8BB3,0x8BB5,0x8BB7,0x8BB8,0x8BBC,0x8C61,0x8C62,0x8C63,
   0x8C65,0x8C69,0x8C6B,0x8C71,0x8C73,0x8C75,0x8C76,0x8C77, 0x8C7B,0x8C81,0x8C82,0x8C85,0x8C89,0x8C91,

   0x8C93,0x8C95,0x8C96,0x8C97,0x8CA1,0x8CA2,0x8CA9,0x8CE1, 0x8CE2,0x8CE3,0x8CE5,0x8CE9,0x8CF1,0x8CF3,0x8CF5,0x8CF6,
   0x8CF7,0x8D41,0x8D42,0x8D45,0x8D51,0x8D55,0x8D57,0x8D61, 0x8D65,0x8D69,0x8D75,0x8D76,0x8D7B,0x8D81,0x8DA1,0x8DA2,
   0x8DA5,0x8DA7,0x8DA9,0x8DB1,0x8DB3,0x8DB5,0x8DB7,0x8DB8, 0x8DB9,0x8DC1,0x8DC2,0x8DC9,0x8DD6,0x8DD7,0x8DE1,0x8DE2,
   0x8DF7,0x8E41,0x8E45,0x8E49,0x8E51,0x8E53,0x8E57,0x8E61, 0x8E81,0x8E82,0x8E85,0x8E89,0x8E90,0x8E91,0x8E93,0x8E95,
   0x8E97,0x8E98,0x8EA1,0x8EA9,0x8EB6,0x8EB7,0x8EC1,0x8EC2, 0x8EC5,0x8EC9,0x8ED1,0x8ED3,0x8ED6,0x8EE1,0x8EE5,0x8EE9,
   0x8EF1,0x8EF3,0x8F41,0x8F61,0x8F62,0x8F65,0x8F67,0x8F69, 0x8F6B,0x8F70,0x8F71,0x8F73,0x8F75,0x8F77,

   0x8F7B,0x8FA1,0x8FA2,0x8FA5,0x8FA9,0x8FB1,0x8FB3,0x8FB5, 0x8FB7,0x9061,0x9062,0x9063,0x9065,0x9068,0x9069,0x906A,
   0x906B,0x9071,0x9073,0x9075,0x9076,0x9077,0x9078,0x9079, 0x907B,0x907D,0x9081,0x9082,0x9085,0x9089,0x9091,0x9093,
   0x9095,0x9096,0x9097,0x90A1,0x90A2,0x90A5,0x90A9,0x90B1, 0x90B7,0x90E1,0x90E2,0x90E4,0x90E5,0x90E9,0x90EB,0x90EC,
   0x90F1,0x90F3,0x90F5,0x90F6,0x90F7,0x90FD,0x9141,0x9142, 0x9145,0x9149,0x9151,0x9153,0x9155,0x9156,0x9157,0x9161,
   0x9162,0x9165,0x9169,0x9171,0x9173,0x9176,0x9177,0x917A, 0x9181,0x9185,0x91A1,0x91A2,0x91A5,0x91A9,0x91AB,0x91B1,
   0x91B3,0x91B5,0x91B7,0x91BC,0x91BD,0x91C1,0x91C5,0x91C9, 0x91D6,0x9241,0x9245,0x9249,0x9251,0x9253,

   0x9255,0x9261,0x9262,0x9265,0x9269,0x9273,0x9275,0x9277, 0x9281,0x9282,0x9285,0x9288,0x9289,0x9291,0x9293,0x9295,
   0x9297,0x92A1,0x92B6,0x92C1,0x92E1,0x92E5,0x92E9,0x92F1, 0x92F3,0x9341,0x9342,0x9349,0x9351,0x9353,0x9357,0x9361,
   0x9362,0x9365,0x9369,0x936A,0x936B,0x9371,0x9373,0x9375, 0x9377,0x9378,0x937C,0x9381,0x9385,0x9389,0x93A1,0x93A2,
   0x93A5,0x93A9,0x93AF,0x93B1,0x93B3,0x93B5,0x93B7,0x93BC, 0x9461,0x9462,0x9463,0x9465,0x9468,0x9469,0x946A,0x946B,
   0x946C,0x9470,0x9471,0x9473,0x9475,0x9476,0x9477,0x9478, 0x9479,0x947D,0x9481,0x9482,0x9485,0x9489,0x9491,0x9493,
   0x9495,0x9496,0x9497,0x94A1,0x94E1,0x94E2,0x94E3,0x94E5, 0x94E8,0x94E9,0x94EB,0x94EC,0x94F1,0x94F3,

   0x94F5,0x94F7,0x94F9,0x94FC,0x9541,0x9542,0x9545,0x9549, 0x9551,0x9553,0x9555,0x9556,0x9557,0x9561,0x9565,0x9569,
   0x9576,0x9577,0x9581,0x9585,0x95A1,0x95A2,0x95A5,0x95A8, 0x95A9,0x95AB,0x95AD,0x95B1,0x95B3,0x95B5,0x95B7,0x95B9,
   0x95BB,0x95C1,0x95C5,0x95C9,0x95E1,0x95F6,0x9641,0x9645, 0x9649,0x9651,0x9653,0x9655,0x9661,0x9681,0x9682,0x9685,
   0x9689,0x9691,0x9693,0x9695,0x9697,0x96A1,0x96B6,0x96C1, 0x96D7,0x96E1,0x96E5,0x96E9,0x96F3,0x96F5,0x96F7,0x9741,
   0x9745,0x9749,0x9751,0x9757,0x9761,0x9762,0x9765,0x9768, 0x9769,0x976B,0x9771,0x9773,0x9775,0x9777,0x9781,0x97A1,
   0x97A2,0x97A5,0x97A8,0x97A9,0x97B1,0x97B3,0x97B5,0x97B6, 0x97B7,0x97B8,0x9861,0x9862,0x9865,0x9869,

   0x9871,0x9873,0x9875,0x9876,0x9877,0x987D,0x9881,0x9882, 0x9885,0x9889,0x9891,0x9893,0x9895,0x9896,0x9897,0x98E1,
   0x98E2,0x98E5,0x98E9,0x98EB,0x98EC,0x98F1,0x98F3,0x98F5, 0x98F6,0x98F7,0x98FD,0x9941,0x9942,0x9945,0x9949,0x9951,
   0x9953,0x9955,0x9956,0x9957,0x9961,0x9976,0x99A1,0x99A2, 0x99A5,0x99A9,0x99B7,0x99C1,0x99C9,0x99E1,0x9A41,0x9A45,
   0x9A81,0x9A82,0x9A85,0x9A89,0x9A90,0x9A91,0x9A97,0x9AC1, 0x9AE1,0x9AE5,0x9AE9,0x9AF1,0x9AF3,0x9AF7,0x9B61,0x9B62,
   0x9B65,0x9B68,0x9B69,0x9B71,0x9B73,0x9B75,0x9B81,0x9B85, 0x9B89,0x9B91,0x9B93,0x9BA1,0x9BA5,0x9BA9,0x9BB1,0x9BB3,
   0x9BB5,0x9BB7,0x9C61,0x9C62,0x9C65,0x9C69,0x9C71,0x9C73, 0x9C75,0x9C76,0x9C77,0x9C78,0x9C7C,0x9C7D,

   0x9C81,0x9C82,0x9C85,0x9C89,0x9C91,0x9C93,0x9C95,0x9C96, 0x9C97,0x9CA1,0x9CA2,0x9CA5,0x9CB5,0x9CB7,0x9CE1,0x9CE2,
   0x9CE5,0x9CE9,0x9CF1,0x9CF3,0x9CF5,0x9CF6,0x9CF7,0x9CFD, 0x9D41,0x9D42,0x9D45,0x9D49,0x9D51,0x9D53,0x9D55,0x9D57,
   0x9D61,0x9D62,0x9D65,0x9D69,0x9D71,0x9D73,0x9D75,0x9D76, 0x9D77,0x9D81,0x9D85,0x9D93,0x9D95,0x9DA1,0x9DA2,0x9DA5,
   0x9DA9,0x9DB1,0x9DB3,0x9DB5,0x9DB7,0x9DC1,0x9DC5,0x9DD7, 0x9DF6,0x9E41,0x9E45,0x9E49,0x9E51,0x9E53,0x9E55,0x9E57,
   0x9E61,0x9E65,0x9E69,0x9E73,0x9E75,0x9E77,0x9E81,0x9E82, 0x9E85,0x9E89,0x9E91,0x9E93,0x9E95,0x9E97,0x9EA1,0x9EB6,
   0x9EC1,0x9EE1,0x9EE2,0x9EE5,0x9EE9,0x9EF1,0x9EF5,0x9EF7, 0x9F41,0x9F42,0x9F45,0x9F49,0x9F51,0x9F53,

   0x9F55,0x9F57,0x9F61,0x9F62,0x9F65,0x9F69,0x9F71,0x9F73, 0x9F75,0x9F77,0x9F78,0x9F7B,0x9F7C,0x9FA1,0x9FA2,0x9FA5,
   0x9FA9,0x9FB1,0x9FB3,0x9FB5,0x9FB7,0xA061,0xA062,0xA065, 0xA067,0xA068,0xA069,0xA06A,0xA06B,0xA071,0xA073,0xA075,
   0xA077,0xA078,0xA07B,0xA07D,0xA081,0xA082,0xA085,0xA089, 0xA091,0xA093,0xA095,0xA096,0xA097,0xA098,0xA0A1,0xA0A2,
   0xA0A9,0xA0B7,0xA0E1,0xA0E2,0xA0E5,0xA0E9,0xA0EB,0xA0F1, 0xA0F3,0xA0F5,0xA0F7,0xA0F8,0xA0FD,0xA141,0xA142,0xA145,
   0xA149,0xA151,0xA153,0xA155,0xA156,0xA157,0xA161,0xA162, 0xA165,0xA169,0xA175,0xA176,0xA177,0xA179,0xA181,0xA1A1,
   0xA1A2,0xA1A4,0xA1A5,0xA1A9,0xA1AB,0xA1B1,0xA1B3,0xA1B5, 0xA1B7,0xA1C1,0xA1C5,0xA1D6,0xA1D7,0xA241,

   0xA245,0xA249,0xA253,0xA255,0xA257,0xA261,0xA265,0xA269, 0xA273,0xA275,0xA281,0xA282,0xA283,0xA285,0xA288,0xA289,
   0xA28A,0xA28B,0xA291,0xA293,0xA295,0xA297,0xA29B,0xA29D, 0xA2A1,0xA2A5,0xA2A9,0xA2B3,0xA2B5,0xA2C1,0xA2E1,0xA2E5,
   0xA2E9,0xA341,0xA345,0xA349,0xA351,0xA355,0xA361,0xA365, 0xA369,0xA371,0xA375,0xA3A1,0xA3A2,0xA3A5,0xA3A8,0xA3A9,
   0xA3AB,0xA3B1,0xA3B3,0xA3B5,0xA3B6,0xA3B7,0xA3B9,0xA3BB, 0xA461,0xA462,0xA463,0xA464,0xA465,0xA468,0xA469,0xA46A,
   0xA46B,0xA46C,0xA471,0xA473,0xA475,0xA477,0xA47B,0xA481, 0xA482,0xA485,0xA489,0xA491,0xA493,0xA495,0xA496,0xA497,
   0xA49B,0xA4A1,0xA4A2,0xA4A5,0xA4B3,0xA4E1,0xA4E2,0xA4E5, 0xA4E8,0xA4E9,0xA4EB,0xA4F1,0xA4F3,0xA4F5,

   0xA4F7,0xA4F8,0xA541,0xA542,0xA545,0xA548,0xA549,0xA551, 0xA553,0xA555,0xA556,0xA557,0xA561,0xA562,0xA565,0xA569,
   0xA573,0xA575,0xA576,0xA577,0xA57B,0xA581,0xA585,0xA5A1, 0xA5A2,0xA5A3,0xA5A5,0xA5A9,0xA5B1,0xA5B3,0xA5B5,0xA5B7,
   0xA5C1,0xA5C5,0xA5D6,0xA5E1,0xA5F6,0xA641,0xA642,0xA645, 0xA649,0xA651,0xA653,0xA661,0xA665,0xA681,0xA682,0xA685,
   0xA688,0xA689,0xA68A,0xA68B,0xA691,0xA693,0xA695,0xA697, 0xA69B,0xA69C,0xA6A1,0xA6A9,0xA6B6,0xA6C1,0xA6E1,0xA6E2,
   0xA6E5,0xA6E9,0xA6F7,0xA741,0xA745,0xA749,0xA751,0xA755, 0xA757,0xA761,0xA762,0xA765,0xA769,0xA771,0xA773,0xA775,
   0xA7A1,0xA7A2,0xA7A5,0xA7A9,0xA7AB,0xA7B1,0xA7B3,0xA7B5, 0xA7B7,0xA7B8,0xA7B9,0xA861,0xA862,0xA865,

   0xA869,0xA86B,0xA871,0xA873,0xA875,0xA876,0xA877,0xA87D, 0xA881,0xA882,0xA885,0xA889,0xA891,0xA893,0xA895,0xA896,
   0xA897,0xA8A1,0xA8A2,0xA8B1,0xA8E1,0xA8E2,0xA8E5,0xA8E8, 0xA8E9,0xA8F1,0xA8F5,0xA8F6,0xA8F7,0xA941,0xA957,0xA961,
   0xA962,0xA971,0xA973,0xA975,0xA976,0xA977,0xA9A1,0xA9A2, 0xA9A5,0xA9A9,0xA9B1,0xA9B3,0xA9B7,0xAA41,0xAA61,0xAA77,
   0xAA81,0xAA82,0xAA85,0xAA89,0xAA91,0xAA95,0xAA97,0xAB41, 0xAB57,0xAB61,0xAB65,0xAB69,0xAB71,0xAB73,0xABA1,0xABA2,
   0xABA5,0xABA9,0xABB1,0xABB3,0xABB5,0xABB7,0xAC61,0xAC62, 0xAC64,0xAC65,0xAC68,0xAC69,0xAC6A,0xAC6B,0xAC71,0xAC73,
   0xAC75,0xAC76,0xAC77,0xAC7B,0xAC81,0xAC82,0xAC85,0xAC89, 0xAC91,0xAC93,0xAC95,0xAC96,0xAC97,0xACA1,

   0xACA2,0xACA5,0xACA9,0xACB1,0xACB3,0xACB5,0xACB7,0xACC1, 0xACC5,0xACC9,0xACD1,0xACD7,0xACE1,0xACE2,0xACE3,0xACE4,
   0xACE5,0xACE8,0xACE9,0xACEB,0xACEC,0xACF1,0xACF3,0xACF5, 0xACF6,0xACF7,0xACFC,0xAD41,0xAD42,0xAD45,0xAD49,0xAD51,
   0xAD53,0xAD55,0xAD56,0xAD57,0xAD61,0xAD62,0xAD65,0xAD69, 0xAD71,0xAD73,0xAD75,0xAD76,0xAD77,0xAD81,0xAD85,0xAD89,
   0xAD97,0xADA1,0xADA2,0xADA3,0xADA5,0xADA9,0xADAB,0xADB1, 0xADB3,0xADB5,0xADB7,0xADBB,0xADC1,0xADC2,0xADC5,0xADC9,
   0xADD7,0xADE1,0xADE5,0xADE9,0xADF1,0xADF5,0xADF6,0xAE41, 0xAE45,0xAE49,0xAE51,0xAE53,0xAE55,0xAE61,0xAE62,0xAE65,
   0xAE69,0xAE71,0xAE73,0xAE75,0xAE77,0xAE81,0xAE82,0xAE85, 0xAE88,0xAE89,0xAE91,0xAE93,0xAE95,0xAE97,

   0xAE99,0xAE9B,0xAE9C,0xAEA1,0xAEB6,0xAEC1,0xAEC2,0xAEC5, 0xAEC9,0xAED1,0xAED7,0xAEE1,0xAEE2,0xAEE5,0xAEE9,0xAEF1,
   0xAEF3,0xAEF5,0xAEF7,0xAF41,0xAF42,0xAF49,0xAF51,0xAF55, 0xAF57,0xAF61,0xAF62,0xAF65,0xAF69,0xAF6A,0xAF71,0xAF73,
   0xAF75,0xAF77,0xAFA1,0xAFA2,0xAFA5,0xAFA8,0xAFA9,0xAFB0, 0xAFB1,0xAFB3,0xAFB5,0xAFB7,0xAFBC,0xB061,0xB062,0xB064,
   0xB065,0xB069,0xB071,0xB073,0xB076,0xB077,0xB07D,0xB081, 0xB082,0xB085,0xB089,0xB091,0xB093,0xB096,0xB097,0xB0B7,
   0xB0E1,0xB0E2,0xB0E5,0xB0E9,0xB0EB,0xB0F1,0xB0F3,0xB0F6, 0xB0F7,0xB141,0xB145,0xB149,0xB157,0xB1A1,0xB1A2,0xB1A5,
   0xB1A8,0xB1A9,0xB1AB,0xB1B1,0xB1B3,0xB1B7,0xB1C1,0xB1C2, 0xB1C5,0xB1D6,0xB1E1,0xB1F6,0xB241,0xB245,

   0xB249,0xB251,0xB253,0xB261,0xB281,0xB282,0xB285,0xB289, 0xB291,0xB293,0xB297,0xB2A1,0xB2B6,0xB2C1,0xB2E1,0xB2E5,
   0xB357,0xB361,0xB362,0xB365,0xB369,0xB36B,0xB370,0xB371, 0xB373,0xB381,0xB385,0xB389,0xB391,0xB3A1,0xB3A2,0xB3A5,
   0xB3A9,0xB3B1,0xB3B3,0xB3B5,0xB3B7,0xB461,0xB462,0xB465, 0xB466,0xB467,0xB469,0xB46A,0xB46B,0xB470,0xB471,0xB473,
   0xB475,0xB476,0xB477,0xB47B,0xB47C,0xB481,0xB482,0xB485, 0xB489,0xB491,0xB493,0xB495,0xB496,0xB497,0xB4A1,0xB4A2,
   0xB4A5,0xB4A9,0xB4AC,0xB4B1,0xB4B3,0xB4B5,0xB4B7,0xB4BB, 0xB4BD,0xB4C1,0xB4C5,0xB4C9,0xB4D3,0xB4E1,0xB4E2,0xB4E5,
   0xB4E6,0xB4E8,0xB4E9,0xB4EA,0xB4EB,0xB4F1,0xB4F3,0xB4F4, 0xB4F5,0xB4F6,0xB4F7,0xB4F8,0xB4FA,0xB4FC,

   0xB541,0xB542,0xB545,0xB549,0xB551,0xB553,0xB555,0xB557, 0xB561,0xB562,0xB563,0xB565,0xB569,0xB56B,0xB56C,0xB571,
   0xB573,0xB574,0xB575,0xB576,0xB577,0xB57B,0xB57C,0xB57D, 0xB581,0xB585,0xB589,0xB591,0xB593,0xB595,0xB596,0xB5A1,
   0xB5A2,0xB5A5,0xB5A9,0xB5AA,0xB5AB,0xB5AD,0xB5B0,0xB5B1, 0xB5B3,0xB5B5,0xB5B7,0xB5B9,0xB5C1,0xB5C2,0xB5C5,0xB5C9,
   0xB5D1,0xB5D3,0xB5D5,0xB5D6,0xB5D7,0xB5E1,0xB5E2,0xB5E5, 0xB5F1,0xB5F5,0xB5F7,0xB641,0xB642,0xB645,0xB649,0xB651,
   0xB653,0xB655,0xB657,0xB661,0xB662,0xB665,0xB669,0xB671, 0xB673,0xB675,0xB677,0xB681,0xB682,0xB685,0xB689,0xB68A,
   0xB68B,0xB691,0xB693,0xB695,0xB697,0xB6A1,0xB6A2,0xB6A5, 0xB6A9,0xB6B1,0xB6B3,0xB6B6,0xB6B7,0xB6C1,

   0xB6C2,0xB6C5,0xB6C9,0xB6D1,0xB6D3,0xB6D7,0xB6E1,0xB6E2, 0xB6E5,0xB6E9,0xB6F1,0xB6F3,0xB6F5,0xB6F7,0xB741,0xB742,
   0xB745,0xB749,0xB751,0xB753,0xB755,0xB757,0xB759,0xB761, 0xB762,0xB765,0xB769,0xB76F,0xB771,0xB773,0xB775,0xB777,
   0xB778,0xB779,0xB77A,0xB77B,0xB77C,0xB77D,0xB781,0xB785, 0xB789,0xB791,0xB795,0xB7A1,0xB7A2,0xB7A5,0xB7A9,0xB7AA,
   0xB7AB,0xB7B0,0xB7B1,0xB7B3,0xB7B5,0xB7B6,0xB7B7,0xB7B8, 0xB7BC,0xB861,0xB862,0xB865,0xB867,0xB868,0xB869,0xB86B,
   0xB871,0xB873,0xB875,0xB876,0xB877,0xB878,0xB881,0xB882, 0xB885,0xB889,0xB891,0xB893,0xB895,0xB896,0xB897,0xB8A1,
   0xB8A2,0xB8A5,0xB8A7,0xB8A9,0xB8B1,0xB8B7,0xB8C1,0xB8C5, 0xB8C9,0xB8E1,0xB8E2,0xB8E5,0xB8E9,0xB8EB,

   0xB8F1,0xB8F3,0xB8F5,0xB8F7,0xB8F8,0xB941,0xB942,0xB945, 0xB949,0xB951,0xB953,0xB955,0xB957,0xB961,0xB965,0xB969,
   0xB971,0xB973,0xB976,0xB977,0xB981,0xB9A1,0xB9A2,0xB9A5, 0xB9A9,0xB9AB,0xB9B1,0xB9B3,0xB9B5,0xB9B7,0xB9B8,0xB9B9,
   0xB9BD,0xB9C1,0xB9C2,0xB9C9,0xB9D3,0xB9D5,0xB9D7,0xB9E1, 0xB9F6,0xB9F7,0xBA41,0xBA45,0xBA49,0xBA51,0xBA53,0xBA55,
   0xBA57,0xBA61,0xBA62,0xBA65,0xBA77,0xBA81,0xBA82,0xBA85, 0xBA89,0xBA8A,0xBA8B,0xBA91,0xBA93,0xBA95,0xBA97,0xBAA1,
   0xBAB6,0xBAC1,0xBAE1,0xBAE2,0xBAE5,0xBAE9,0xBAF1,0xBAF3, 0xBAF5,0xBB41,0xBB45,0xBB49,0xBB51,0xBB61,0xBB62,0xBB65,
   0xBB69,0xBB71,0xBB73,0xBB75,0xBB77,0xBBA1,0xBBA2,0xBBA5, 0xBBA8,0xBBA9,0xBBAB,0xBBB1,0xBBB3,0xBBB5,

   0xBBB7,0xBBB8,0xBBBB,0xBBBC,0xBC61,0xBC62,0xBC65,0xBC67, 0xBC69,0xBC6C,0xBC71,0xBC73,0xBC75,0xBC76,0xBC77,0xBC81,
   0xBC82,0xBC85,0xBC89,0xBC91,0xBC93,0xBC95,0xBC96,0xBC97, 0xBCA1,0xBCA5,0xBCB7,0xBCE1,0xBCE2,0xBCE5,0xBCE9,0xBCF1,
   0xBCF3,0xBCF5,0xBCF6,0xBCF7,0xBD41,0xBD57,0xBD61,0xBD76, 0xBDA1,0xBDA2,0xBDA5,0xBDA9,0xBDB1,0xBDB3,0xBDB5,0xBDB7,
   0xBDB9,0xBDC1,0xBDC2,0xBDC9,0xBDD6,0xBDE1,0xBDF6,0xBE41, 0xBE45,0xBE49,0xBE51,0xBE53,0xBE77,0xBE81,0xBE82,0xBE85,
   0xBE89,0xBE91,0xBE93,0xBE97,0xBEA1,0xBEB6,0xBEB7,0xBEE1, 0xBF41,0xBF61,0xBF71,0xBF75,0xBF77,0xBFA1,0xBFA2,0xBFA5,
   0xBFA9,0xBFB1,0xBFB3,0xBFB7,0xBFB8,0xBFBD,0xC061,0xC062, 0xC065,0xC067,0xC069,0xC071,0xC073,0xC075,

   0xC076,0xC077,0xC078,0xC081,0xC082,0xC085,0xC089,0xC091, 0xC093,0xC095,0xC096,0xC097,0xC0A1,0xC0A5,0xC0A7,0xC0A9,
   0xC0B1,0xC0B7,0xC0E1,0xC0E2,0xC0E5,0xC0E9,0xC0F1,0xC0F3, 0xC0F5,0xC0F6,0xC0F7,0xC141,0xC142,0xC145,0xC149,0xC151,
   0xC153,0xC155,0xC157,0xC161,0xC165,0xC176,0xC181,0xC185, 0xC197,0xC1A1,0xC1A2,0xC1A5,0xC1A9,0xC1B1,0xC1B3,0xC1B5,
   0xC1B7,0xC1C1,0xC1C5,0xC1C9,0xC1D7,0xC241,0xC245,0xC249, 0xC251,0xC253,0xC255,0xC257,0xC261,0xC271,0xC281,0xC282,
   0xC285,0xC289,0xC291,0xC293,0xC295,0xC297,0xC2A1,0xC2B6, 0xC2C1,0xC2C5,0xC2E1,0xC2E5,0xC2E9,0xC2F1,0xC2F3,0xC2F5,
   0xC2F7,0xC341,0xC345,0xC349,0xC351,0xC357,0xC361,0xC362, 0xC365,0xC369,0xC371,0xC373,0xC375,0xC377,

   0xC3A1,0xC3A2,0xC3A5,0xC3A8,0xC3A9,0xC3AA,0xC3B1,0xC3B3, 0xC3B5,0xC3B7,0xC461,0xC462,0xC465,0xC469,0xC471,0xC473,
   0xC475,0xC477,0xC481,0xC482,0xC485,0xC489,0xC491,0xC493, 0xC495,0xC496,0xC497,0xC4A1,0xC4A2,0xC4B7,0xC4E1,0xC4E2,
   0xC4E5,0xC4E8,0xC4E9,0xC4F1,0xC4F3,0xC4F5,0xC4F6,0xC4F7, 0xC541,0xC542,0xC545,0xC549,0xC551,0xC553,0xC555,0xC557,
   0xC561,0xC565,0xC569,0xC571,0xC573,0xC575,0xC576,0xC577, 0xC581,0xC5A1,0xC5A2,0xC5A5,0xC5A9,0xC5B1,0xC5B3,0xC5B5,
   0xC5B7,0xC5C1,0xC5C2,0xC5C5,0xC5C9,0xC5D1,0xC5D7,0xC5E1, 0xC5F7,0xC641,0xC649,0xC661,0xC681,0xC682,0xC685,0xC689,
   0xC691,0xC693,0xC695,0xC697,0xC6A1,0xC6A5,0xC6A9,0xC6B7, 0xC6C1,0xC6D7,0xC6E1,0xC6E2,0xC6E5,0xC6E9,

   0xC6F1,0xC6F3,0xC6F5,0xC6F7,0xC741,0xC745,0xC749,0xC751, 0xC761,0xC762,0xC765,0xC769,0xC771,0xC773,0xC777,0xC7A1,
   0xC7A2,0xC7A5,0xC7A9,0xC7B1,0xC7B3,0xC7B5,0xC7B7,0xC861, 0xC862,0xC865,0xC869,0xC86A,0xC871,0xC873,0xC875,0xC876,
   0xC877,0xC881,0xC882,0xC885,0xC889,0xC891,0xC893,0xC895, 0xC896,0xC897,0xC8A1,0xC8B7,0xC8E1,0xC8E2,0xC8E5,0xC8E9,
   0xC8EB,0xC8F1,0xC8F3,0xC8F5,0xC8F6,0xC8F7,0xC941,0xC942, 0xC945,0xC949,0xC951,0xC953,0xC955,0xC957,0xC961,0xC965,
   0xC976,0xC981,0xC985,0xC9A1,0xC9A2,0xC9A5,0xC9A9,0xC9B1, 0xC9B3,0xC9B5,0xC9B7,0xC9BC,0xC9C1,0xC9C5,0xC9E1,0xCA41,
   0xCA45,0xCA55,0xCA57,0xCA61,0xCA81,0xCA82,0xCA85,0xCA89, 0xCA91,0xCA93,0xCA95,0xCA97,0xCAA1,0xCAB6,

   0xCAC1,0xCAE1,0xCAE2,0xCAE5,0xCAE9,0xCAF1,0xCAF3,0xCAF7, 0xCB41,0xCB45,0xCB49,0xCB51,0xCB57,0xCB61,0xCB62,0xCB65,
   0xCB68,0xCB69,0xCB6B,0xCB71,0xCB73,0xCB75,0xCB81,0xCB85, 0xCB89,0xCB91,0xCB93,0xCBA1,0xCBA2,0xCBA5,0xCBA9,0xCBB1,
   0xCBB3,0xCBB5,0xCBB7,0xCC61,0xCC62,0xCC63,0xCC65,0xCC69, 0xCC6B,0xCC71,0xCC73,0xCC75,0xCC76,0xCC77,0xCC7B,0xCC81,
   0xCC82,0xCC85,0xCC89,0xCC91,0xCC93,0xCC95,0xCC96,0xCC97, 0xCCA1,0xCCA2,0xCCE1,0xCCE2,0xCCE5,0xCCE9,0xCCF1,0xCCF3,
   0xCCF5,0xCCF6,0xCCF7,0xCD41,0xCD42,0xCD45,0xCD49,0xCD51, 0xCD53,0xCD55,0xCD57,0xCD61,0xCD65,0xCD69,0xCD71,0xCD73,
   0xCD76,0xCD77,0xCD81,0xCD89,0xCD93,0xCD95,0xCDA1,0xCDA2, 0xCDA5,0xCDA9,0xCDB1,0xCDB3,0xCDB5,0xCDB7,

   0xCDC1,0xCDD7,0xCE41,0xCE45,0xCE61,0xCE65,0xCE69,0xCE73, 0xCE75,0xCE81,0xCE82,0xCE85,0xCE88,0xCE89,0xCE8B,0xCE91,
   0xCE93,0xCE95,0xCE97,0xCEA1,0xCEB7,0xCEE1,0xCEE5,0xCEE9, 0xCEF1,0xCEF5,0xCF41,0xCF45,0xCF49,0xCF51,0xCF55,0xCF57,
   0xCF61,0xCF65,0xCF69,0xCF71,0xCF73,0xCF75,0xCFA1,0xCFA2, 0xCFA5,0xCFA9,0xCFB1,0xCFB3,0xCFB5,0xCFB7,0xD061,0xD062,
   0xD065,0xD069,0xD06E,0xD071,0xD073,0xD075,0xD077,0xD081, 0xD082,0xD085,0xD089,0xD091,0xD093,0xD095,0xD096,0xD097,
   0xD0A1,0xD0B7,0xD0E1,0xD0E2,0xD0E5,0xD0E9,0xD0EB,0xD0F1, 0xD0F3,0xD0F5,0xD0F7,0xD141,0xD142,0xD145,0xD149,0xD151,
   0xD153,0xD155,0xD157,0xD161,0xD162,0xD165,0xD169,0xD171, 0xD173,0xD175,0xD176,0xD177,0xD181,0xD185,

   0xD189,0xD193,0xD1A1,0xD1A2,0xD1A5,0xD1A9,0xD1AE,0xD1B1, 0xD1B3,0xD1B5,0xD1B7,0xD1BB,0xD1C1,0xD1C2,0xD1C5,0xD1C9,
   0xD1D5,0xD1D7,0xD1E1,0xD1E2,0xD1E5,0xD1F5,0xD1F7,0xD241, 0xD242,0xD245,0xD249,0xD253,0xD255,0xD257,0xD261,0xD265,
   0xD269,0xD273,0xD275,0xD281,0xD282,0xD285,0xD289,0xD28E, 0xD291,0xD295,0xD297,0xD2A1,0xD2A5,0xD2A9,0xD2B1,0xD2B7,
   0xD2C1,0xD2C2,0xD2C5,0xD2C9,0xD2D7,0xD2E1,0xD2E2,0xD2E5, 0xD2E9,0xD2F1,0xD2F3,0xD2F5,0xD2F7,0xD341,0xD342,0xD345,
   0xD349,0xD351,0xD355,0xD357,0xD361,0xD362,0xD365,0xD367, 0xD368,0xD369,0xD36A,0xD371,0xD373,0xD375,0xD377,0xD37B,
   0xD381,0xD385,0xD389,0xD391,0xD393,0xD397,0xD3A1,0xD3A2, 0xD3A5,0xD3A9,0xD3B1,0xD3B3,0xD3B5,0xD3B7
};

unsigned short g_HAN_SingleTable[51] = { 
   0x8841,0x8C41,0x8444,0x9041,0x8446,0x8447,0x9441,0x9841, 0x9C41,0x844A,0x844B,0x844C,0x844D,0x844E,0x844F,0x8450,
   0xA041,0xA441,0xA841,0x8454,0xAC41,0xB041,0xB441,0xB841, 0xBC41,0xC041,0xC441,0xC841,0xCC41,0xD041,0x8461,0x8481,
   0x84A1,0x84C1,0x84E1,0x8541,0x8561,0x8581,0x85A1,0x85C1, 0x85E1,0x8641,0x8661,0x8681,0x86A1,0x86C1,0x86E1,0x8741,
   0x8761,0x8781,0x87A1
};

unsigned short g_MouseCursor[5][16]={
                {0xc000,0xa000,0x9000,0x8800,0x8400,0x8200,0x8100,0x8080, 0x8040,0x8020,0x83e0,0xb900,0xe980,0x0c80,0x0480,0x0780},
                {0x0000,0x4000,0x6000,0x7000,0x7800,0x7c00,0x7e00,0x7f00, 0x7f80,0x7fc0,0x7c00,0x4600,0x0600,0x0300,0x0300,0x0000},
                {0x0c00,0x1200,0x1200,0x1200,0x1200,0x13b6,0x1249,0x7249, 0x9249,0x9001,0x9001,0x8001,0x4002,0x4002,0x2004,0x1ff8},
                {0x0000,0x0c00,0x0c00,0x0c00,0x0c00,0x0c00,0x0db6,0x0db6, 0x6db6,0x6ffe,0x6ffe,0x7ffe,0x3ffc,0x3ffc,0x1ff8,0x0000},
                {0x0000,0x0012,0x001a,0x0016,0x0012,0x0000,0x0000,0x0000, 0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000}
               };

t_GDC *g_GDC_Main = (t_GDC *)0;	      
int    g_GDC_IsShared = 0;
#if DEF_USE_GDC_SHARED == 1
key_t  g_GDC_Key = (-1);
#endif

t_GDC *OpenGDC(char *s_DeviceName, int s_ResX, int s_ResY, int s_ResBytes)
{
 t_GDC *s_HANDLE_GDC;
 if(s_DeviceName == (char *)0)s_DeviceName = "/dev/fb0"; /* Default device */ 
#if DEF_USE_GDC_SHARED == 1
 g_GDC_Key = shmget((key_t)0x7803, sizeof(t_GDC), IPC_CREAT | 0666);
 if(g_GDC_Key >= 0)
 {
  s_HANDLE_GDC = shmat(g_ConfigKey, (void *)0, 0);
  if(s_HANDLE_GDC == (t_GDC *)0)s_HANDLE_GDC = (t_GDC *)malloc(sizeof(t_GDC));
  else g_GDC_IsShared = 1;
 }
 else s_HANDLE_GDC = (t_GDC *)malloc(sizeof(t_GDC));
#else
 s_HANDLE_GDC = (t_GDC *)malloc(sizeof(t_GDC));
#endif
 if(s_HANDLE_GDC)
 {
  memset(s_HANDLE_GDC, 0, sizeof(t_GDC));
  s_HANDLE_GDC->Next = (t_GDC *)0;
  s_HANDLE_GDC->Handle = open(s_DeviceName, O_RDWR);
  if(s_HANDLE_GDC->Handle >= 0)
  {
   if(ioctl(s_HANDLE_GDC->Handle, FBIOGET_FSCREENINFO, &s_HANDLE_GDC->Info_FIX))
   {
    fprintf(stderr, "GDC: Can not information !!!\n");    
    exit(0);
   }
   /*
   else
   {
    char *s_Type[] = {
           "Packed", "Plane", "Interleaved plane", "Text", "VGA Plane", (char *)0
          };
    char *s_Visual[] = {
	   "Mono01", "Mono10", "True color", "Pseudo color", "Direct color", "Pseudo color (Read only)", (char *)0
	  };
    fprintf(stdout, "GDC: Frame buffer information\n");
    fprintf(stdout, "\tType       = \"%s\"\n", s_Type[s_HANDLE_GDC->Info_FIX.Type]);   
    fprintf(stdout, "\tTypeAUX    = %lu\n", s_HANDLE_GDC->Info_FIX.TypeAUX);   
    fprintf(stdout, "\tTypeVisual = \"%s\"\n", s_Visual[s_HANDLE_GDC->Info_FIX.TypeVisual]);   
    fprintf(stdout, "\tStep X     = %u\n", s_HANDLE_GDC->Info_FIX.StepX);   
    fprintf(stdout, "\tStep Y     = %u\n", s_HANDLE_GDC->Info_FIX.StepY);   
    fprintf(stdout, "\tStep XY    = %u\n", s_HANDLE_GDC->Info_FIX.StepXY);   
    fprintf(stdout, "\tLine length= %lu\n", s_HANDLE_GDC->Info_FIX.LineLength);   
    fprintf(stdout, "\tAccel      = %lu\n", s_HANDLE_GDC->Info_FIX.Accel);   
   }
   */
   s_HANDLE_GDC->ResX              = s_ResX;
   s_HANDLE_GDC->ResY              = s_ResY;
   s_HANDLE_GDC->ResBytes          = s_ResBytes; 
   if(ioctl(s_HANDLE_GDC->Handle, FBIOGET_VSCREENINFO, &s_HANDLE_GDC->Info_VAR))
   {
    fprintf(stderr, "GDC: Can not information vaiable !!!\n");
    exit(0);   
   }
   else
   {
   /*
    fprintf(stdout, "\tResolutionX= %lu\n", s_HANDLE_GDC->Info_VAR.ResX);   
    fprintf(stdout, "\tResolutionY= %lu\n", s_HANDLE_GDC->Info_VAR.ResY);   
    fprintf(stdout, "\tVirtualX   = %lu\n", s_HANDLE_GDC->Info_VAR.VirtualX);   
    fprintf(stdout, "\tVirtualY   = %lu\n", s_HANDLE_GDC->Info_VAR.VirtualY);   
    fprintf(stdout, "\tBits per pixel = %lu\n", s_HANDLE_GDC->Info_VAR.BPP);   
    fprintf(stdout, "\tOffsetX    = %lu\n", s_HANDLE_GDC->Info_VAR.OffsetX);   
    fprintf(stdout, "\tOffsetY    = %lu\n", s_HANDLE_GDC->Info_VAR.OffsetY);   
    fprintf(stdout, "\tHeight     = %lu\n", s_HANDLE_GDC->Info_VAR.Height);   
    fprintf(stdout, "\tWidth      = %lu\n", s_HANDLE_GDC->Info_VAR.Width);   
    fprintf(stdout, "\tVMode      = %lu\n", s_HANDLE_GDC->Info_VAR.VMode);   
   */
    if(s_HANDLE_GDC->ResX <= 0)s_HANDLE_GDC->ResX = (int)s_HANDLE_GDC->Info_VAR.ResX;
    if(s_HANDLE_GDC->ResY <= 0)s_HANDLE_GDC->ResY = (int)s_HANDLE_GDC->Info_VAR.ResY;
    if(s_HANDLE_GDC->ResBytes <= 0)s_HANDLE_GDC->ResBytes = (int)(s_HANDLE_GDC->Info_VAR.BPP >> 3);
   }
   s_HANDLE_GDC->Clipping[0]       = 0;
   s_HANDLE_GDC->Clipping[1]       = 0;
   s_HANDLE_GDC->Clipping[2]       = s_HANDLE_GDC->ResX - 1;
   s_HANDLE_GDC->Clipping[3]       = s_HANDLE_GDC->ResY - 1;
   s_HANDLE_GDC->MapSize           = s_HANDLE_GDC->ResX * s_HANDLE_GDC->ResY * s_HANDLE_GDC->ResBytes;
#if DEF_USE_DRAWMODE == 0 /* RGB -> RGB */
   s_HANDLE_GDC->BaseAddress       = mmap(NULL, s_HANDLE_GDC->MapSize + 1, PROT_READ | PROT_WRITE, MAP_SHARED, s_HANDLE_GDC->Handle, 0);
#elif DEF_USE_DRAWMODE == 1 /* RGB -> YCbCr */
   s_HANDLE_GDC->WorkAddress       = mmap(NULL, s_HANDLE_GDC->MapSize + 1, PROT_READ | PROT_WRITE, MAP_SHARED, s_HANDLE_GDC->Handle, 0);
   s_HANDLE_GDC->BaseAddress       = malloc(s_HANDLE_GDC->MapSize + 1);
#endif
   if(s_HANDLE_GDC->BaseAddress)
   {
    s_HANDLE_GDC->LeftAddress       = (s_HANDLE_GDC->Clipping[1] * s_HANDLE_GDC->ResX) + s_HANDLE_GDC->Clipping[0];
    s_HANDLE_GDC->RightAddress      = (s_HANDLE_GDC->Clipping[3] * s_HANDLE_GDC->ResX) + s_HANDLE_GDC->Clipping[2];
    s_HANDLE_GDC->OffsetX           = (int *)malloc(s_HANDLE_GDC->ResX * sizeof(int)); /* Core #0000 */
    s_HANDLE_GDC->OffsetY           = (int *)malloc(s_HANDLE_GDC->ResY * sizeof(int)); /* Core #0001 */
    if(s_HANDLE_GDC->OffsetX && s_HANDLE_GDC->OffsetY) 
    {
     int s_Count;  
     for(s_Count = 0;s_Count < s_HANDLE_GDC->ResY;s_Count++) /* Build speed up table - Fast access y */
     {
      *(((int *)s_HANDLE_GDC->OffsetY) + s_Count) = (s_Count * s_HANDLE_GDC->ResX * s_HANDLE_GDC->ResBytes); 
     }
     for(s_Count = 0;s_Count < s_HANDLE_GDC->ResX;s_Count++) /* Build speed up table - Fast access x */
     {
      *(((int *)s_HANDLE_GDC->OffsetX) + s_Count) = (s_Count * s_HANDLE_GDC->ResBytes); 
     }
     s_HANDLE_GDC->FontScaleX     = s_HANDLE_GDC->FontScaleY     = 1;
     s_HANDLE_GDC->FontScaleX_dot = s_HANDLE_GDC->FontScaleY_dot = 0;
     s_HANDLE_GDC->MouseHandle    = (-1);
     s_HANDLE_GDC->MouseX         = s_HANDLE_GDC->ResX >> 1;
     s_HANDLE_GDC->MouseY         = s_HANDLE_GDC->ResY >> 1;
     s_HANDLE_GDC->MouseButton    = 0;
     s_HANDLE_GDC->MouseEvent     = 0;
    }
    else
    {
     if(s_HANDLE_GDC->OffsetX)free(s_HANDLE_GDC->OffsetX);	
     if(s_HANDLE_GDC->OffsetY)free(s_HANDLE_GDC->OffsetY);	
#if DEF_USE_DRAWMODE == 0 /* RGB -> RGB */
     munmap(s_HANDLE_GDC->BaseAddress, s_HANDLE_GDC->MapSize);     
#elif DEF_USE_DRAWMODE == 1 /* RGB -> YCbCr */
     munmap(s_HANDLE_GDC->WorkAddress, s_HANDLE_GDC->MapSize);     
     free(s_HANDLE_GDC->BaseAddress); 
#endif
     goto L_OpenGDC_Error;
    }
   }
   else goto L_OpenGDC_Error;
  }
  else
  {
   L_OpenGDC_Error:;   
   free(s_HANDLE_GDC);
   s_HANDLE_GDC = (t_GDC *)0;  
  } 
 }
 return(s_HANDLE_GDC); 
}

t_GDC *CloseGDC(t_GDC *s_HANDLE_GDC)
{
 if(s_HANDLE_GDC)
 {
  if(s_HANDLE_GDC->MouseHandle >= 0)GDC_CloseMouse(s_HANDLE_GDC);
  if(s_HANDLE_GDC->KeyboardHandle  )GDC_CloseKeyboard(s_HANDLE_GDC); 
#if DEF_USE_DRAWMODE == 0 /* RGB -> RGB */
  if(s_HANDLE_GDC->BaseAddress)munmap(s_HANDLE_GDC->BaseAddress, s_HANDLE_GDC->MapSize);
#elif DEF_USE_DRAWMODE == 1 /* RGB -> YCbCr */
  if(s_HANDLE_GDC->WorkAddress)munmap(s_HANDLE_GDC->WorkAddress, s_HANDLE_GDC->MapSize);
  if(s_HANDLE_GDC->BaseAddress)free(s_HANDLE_GDC->BaseAddress);
#endif
  if(s_HANDLE_GDC->Handle >= 0)close(s_HANDLE_GDC->Handle);
  if(s_HANDLE_GDC->OffsetX    )free(s_HANDLE_GDC->OffsetX); 
  if(s_HANDLE_GDC->OffsetY    )free(s_HANDLE_GDC->OffsetY); 
#if DEF_USE_GDC_SHARED == 1
  if(g_GDC_IsShared == 1)shmdt(s_HANDLE_GDC);
  else free(s_HANDLE_GDC); 
#else
  free(s_HANDLE_GDC);
#endif
  s_HANDLE_GDC = (t_GDC *)0;  
 }
 return(s_HANDLE_GDC); 
}

inline int __GDC_Check(t_GDC *s_HANDLE_GDC, int s_x, int s_y)
{
 return(s_x < s_HANDLE_GDC->Clipping[0] || s_y < s_HANDLE_GDC->Clipping[1] || s_x > s_HANDLE_GDC->Clipping[2] || s_y > s_HANDLE_GDC->Clipping[3]);
}

inline void __GDC_CheckSwap(int *s_Min, int *s_Max)
{
 if(*(s_Min) > *(s_Max))
 {
  register int s_Temp = *(s_Min);
  *(s_Min) = *(s_Max);
  *(s_Max) = s_Temp;
 }    
}

inline void __GDC_CheckLimitX(t_GDC *s_HANDLE_GDC, int *s_x)
{
 if(*(s_x) < s_HANDLE_GDC->Clipping[0])*(s_x) = s_HANDLE_GDC->Clipping[0];    
 if(*(s_x) > s_HANDLE_GDC->Clipping[2])*(s_x) = s_HANDLE_GDC->Clipping[2];    
}

inline void __GDC_CheckLimitY(t_GDC *s_HANDLE_GDC, int *s_y)
{
 if(*(s_y) < s_HANDLE_GDC->Clipping[1])*(s_y) = s_HANDLE_GDC->Clipping[1];    
 if(*(s_y) > s_HANDLE_GDC->Clipping[3])*(s_y) = s_HANDLE_GDC->Clipping[3];    
}

int __GDC_GetPixel_01(t_GDC *s_HANDLE_GDC, int s_x, int s_y)
{
 return((int)(*((unsigned char *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x]))));      
}

int __GDC_GetPixel_02(t_GDC *s_HANDLE_GDC, int s_x, int s_y)
{
 return((int)(*((unsigned short *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x]))));      
}

int __GDC_GetPixel_03(t_GDC *s_HANDLE_GDC, int s_x, int s_y)
{
 return((int)((*((unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x])))&0x00ffffff));      
}

int __GDC_GetPixel_04(t_GDC *s_HANDLE_GDC, int s_x, int s_y)
{
 return((int)(*((unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x]))));      
}

inline int GDC_GetPixel(t_GDC *s_HANDLE_GDC, int s_x, int s_y)
{
 DEF_GDC_AUTOINIT();   
 if(__GDC_Check(s_HANDLE_GDC, s_x, s_y))return(0);   
 return(_GDC_GetPixel[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_x, s_y));    
}

void __GDC_SetPixel_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y)
{
 (*((unsigned char *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x]))) = (unsigned char)s_Color;      
}

void __GDC_SetPixel_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y)
{
 (*((unsigned short *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x]))) = (unsigned short)s_Color;      
}

void __GDC_SetPixel_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y)
{ /* 24 bit control */
 unsigned long *s_Ptr = ((unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x]));
 *(s_Ptr) = (unsigned long)s_Color | (*(s_Ptr) & 0xff000000LU);      
}

void __GDC_SetPixel_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y)
{
 (*((unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x]))) = (unsigned long)s_Color;      
}

inline void GDC_SetPixel(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y)
{
 DEF_GDC_AUTOINIT();   
 if(__GDC_Check(s_HANDLE_GDC, s_x, s_y) == 0)_GDC_SetPixel[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Color, s_x, s_y);    
}

inline void GDC_DrawPixel(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y)
{
 DEF_GDC_AUTOINIT();   
 if(__GDC_Check(s_HANDLE_GDC, s_x, s_y) == 0)_GDC_SetPixel[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Color, s_x, s_y);    
}

void __GDC_GetHLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y)
{
 memcpy(s_Buffer, (((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]), (s_x2 - s_x1 + 1));   
}

void __GDC_GetHLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y)
{
 memcpy(s_Buffer, (((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]), (s_x2 - s_x1 + 1) * s_HANDLE_GDC->ResBytes);   
}

void __GDC_GetHLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y)
{
 memcpy(s_Buffer, (((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]), (s_x2 - s_x1 + 1) * s_HANDLE_GDC->ResBytes);   
}

void __GDC_GetHLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y)
{
 memcpy(s_Buffer, (((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]), (s_x2 - s_x1 + 1) * s_HANDLE_GDC->ResBytes);   
}

inline void GDC_GetHLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_x1, &s_x2);   
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x1);
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x2);
 __GDC_CheckLimitY(s_HANDLE_GDC, &s_y);
 if(s_Buffer)_GDC_GetHLine[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Buffer, s_x1, s_x2, s_y);   
}
    
void __GDC_SetHLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y)
{
 memcpy((((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]), s_Buffer, (s_x2 - s_x1 + 1));   
}

void __GDC_SetHLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y)
{
 memcpy((((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]), s_Buffer, (s_x2 - s_x1 + 1) * s_HANDLE_GDC->ResBytes);   
}

void __GDC_SetHLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y)
{
 memcpy((((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]), s_Buffer, (s_x2 - s_x1 + 1) * s_HANDLE_GDC->ResBytes);   
}

void __GDC_SetHLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y)
{
 memcpy((((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]), s_Buffer, (s_x2 - s_x1 + 1) * s_HANDLE_GDC->ResBytes);   
}

inline void GDC_SetHLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_x1, &s_x2);   
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x1);
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x2);
 __GDC_CheckLimitY(s_HANDLE_GDC, &s_y);
 if(s_Buffer)_GDC_SetHLine[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Buffer, s_x1, s_x2, s_y);   
}

void __GDC_DrawHLine_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y)
{
 memset((((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]), s_Color, (s_x2 - s_x1 + 1) * s_HANDLE_GDC->ResBytes);   
}

void __GDC_DrawHLine_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y)
{
 register unsigned short *s_Ptr = (unsigned short *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_x1++ <= s_x2)*(s_Ptr++) = (unsigned short)s_Color;   
}

void __GDC_DrawHLine_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y)
{
 register unsigned long *s_Ptr = (unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_x1++ <= s_x2)
 {
  *(s_Ptr) = ((unsigned long)s_Color) | (*(s_Ptr)&0xff000000LU); 
  ((unsigned char *)s_Ptr)+=3; 
 } 
}

void __GDC_DrawHLine_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y)
{
 register unsigned long *s_Ptr = (unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_x1++ <= s_x2)*(s_Ptr++) = (unsigned long)s_Color;   
}

inline void GDC_DrawHLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_x1, &s_x2);   
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x1);
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x2);
 __GDC_CheckLimitY(s_HANDLE_GDC, &s_y);
 _GDC_DrawHLine[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Color, s_x1, s_x2, s_y);    
}

void __GDC_XORHLine_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y)
{
 register unsigned char *s_Ptr = (unsigned char *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_x1++ <= s_x2)*(s_Ptr++) ^= (unsigned char)s_Color;   
}

void __GDC_XORHLine_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y)
{
 register unsigned short *s_Ptr = (unsigned short *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_x1++ <= s_x2)*(s_Ptr++) ^= (unsigned short)s_Color;   
}

void __GDC_XORHLine_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y)
{
 register unsigned long *s_Ptr = (unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_x1++ <= s_x2)
 {
  *(s_Ptr) = (*(s_Ptr) ^ (unsigned long)s_Color) | (*(s_Ptr)&0xff000000LU); 
  ((unsigned char *)s_Ptr)+=3; 
 } 
}

void __GDC_XORHLine_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y)
{
 register unsigned long *s_Ptr = (unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_x1++ <= s_x2)*(s_Ptr++) ^= (unsigned long)s_Color;   
}

inline void GDC_XORHLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_x1, &s_x2);   
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x1); __GDC_CheckLimitX(s_HANDLE_GDC, &s_x2); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y);
 _GDC_XORHLine[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Color, s_x1, s_x2, s_y);    
}

void __GDC_GetVLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2)
{
 register unsigned char *s_Ptr = (unsigned char *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(((unsigned char *)s_Buffer)++) = *(s_Ptr);
  ((unsigned char *)s_Ptr)        += (s_HANDLE_GDC->ResX);  
 }   
}

void __GDC_GetVLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2)
{
 register unsigned short *s_Ptr = (unsigned short *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(((unsigned short *)s_Buffer)++) = *(s_Ptr);
  ((unsigned char *)s_Ptr)         += (s_HANDLE_GDC->ResX << 1);  
 }   
}

void __GDC_GetVLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2)
{
 register unsigned long *s_Ptr = (unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *((unsigned long *)s_Buffer) = (*(s_Ptr) & 0x00ffffff) | (*((unsigned long *)s_Buffer) & 0xff000000);
  ((unsigned char *)s_Buffer) += 3;
  ((unsigned char *)s_Ptr)    += (s_HANDLE_GDC->ResX * 3);  
 }   
}

void __GDC_GetVLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2)
{
 register unsigned long *s_Ptr = (unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(((unsigned long *)s_Buffer)++) = *(s_Ptr);
  ((unsigned char *)s_Ptr)         += (s_HANDLE_GDC->ResX <<2);  
 }   
}

inline void GDC_GetVLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_y1, &s_y2);
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x); 
 __GDC_CheckLimitY(s_HANDLE_GDC, &s_y1); 
 __GDC_CheckLimitY(s_HANDLE_GDC, &s_y2);
 if(s_Buffer)_GDC_GetVLine[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Buffer, s_x, s_y1, s_y2);
}

void __GDC_SetVLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2)
{
 register unsigned char *s_Ptr = (unsigned char *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(s_Ptr)                  = *(((unsigned char *)s_Buffer)++);   
  ((unsigned char *)s_Ptr) += (s_HANDLE_GDC->ResX);  
 }   
}

void __GDC_SetVLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2)
{
 register unsigned short *s_Ptr = (unsigned short *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(s_Ptr)                  = *(((unsigned short *)s_Buffer)++);   
  ((unsigned char *)s_Ptr) += (s_HANDLE_GDC->ResX << 1);  
 }   
}

void __GDC_SetVLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2)
{
 register unsigned long *s_Ptr = (unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(s_Ptr)                     = (*((unsigned long *)s_Buffer) & 0x00ffffff) | (*(s_Ptr) & 0xff000000);
  ((unsigned char *)s_Buffer) += 3;
  ((unsigned char *)s_Ptr)    += (s_HANDLE_GDC->ResX * 3);  
 }   
}

void __GDC_SetVLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2)
{
 register unsigned long *s_Ptr = (unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(s_Ptr) = *(((unsigned long *)s_Buffer)++);
  ((unsigned char *)s_Ptr)         += (s_HANDLE_GDC->ResX <<2);  
 }   
}    

inline void GDC_SetVLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_y1, &s_y2);
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y1); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y2);
 if(s_Buffer)_GDC_SetVLine[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Buffer, s_x, s_y1, s_y2);
}

void __GDC_DrawVLine_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2)
{
 register unsigned char *s_Ptr = (unsigned char *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(s_Ptr)                  = (unsigned char)s_Color; 
  ((unsigned char *)s_Ptr) += (s_HANDLE_GDC->ResX);  
 }   
}

void __GDC_DrawVLine_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2)
{
 register unsigned short *s_Ptr = (unsigned short *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(s_Ptr)                  = (unsigned short)s_Color; 
  ((unsigned char *)s_Ptr) += (s_HANDLE_GDC->ResX << 1);  
 }   
}

void __GDC_DrawVLine_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2)
{
 register unsigned long *s_Ptr = (unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(s_Ptr)                     = (unsigned long)((s_Color & 0x00ffffff) | (*(s_Ptr) & 0xff000000));
  ((unsigned char *)s_Ptr)    += (s_HANDLE_GDC->ResX * 3);  
 }   
}

void __GDC_DrawVLine_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2)
{
 register unsigned long *s_Ptr = (unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(s_Ptr)                          = (unsigned long)s_Color;
  ((unsigned char *)s_Ptr)         += (s_HANDLE_GDC->ResX <<2);  
 }   
}

inline void GDC_DrawVLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_y1, &s_y2);
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y1); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y2);
 _GDC_DrawVLine[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Color, s_x, s_y1, s_y2);
}

void __GDC_XORVLine_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2)
{
 register unsigned char *s_Ptr = (unsigned char *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(s_Ptr)                 ^= (unsigned char)s_Color; 
  ((unsigned char *)s_Ptr) += (s_HANDLE_GDC->ResX);  
 }   
}

void __GDC_XORVLine_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2)
{
 register unsigned short *s_Ptr = (unsigned short *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(s_Ptr)                 ^= (unsigned short)s_Color; 
  ((unsigned char *)s_Ptr) += (s_HANDLE_GDC->ResX << 1);  
 }   
}

void __GDC_XORVLine_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2)
{
 register unsigned long *s_Ptr = (unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(s_Ptr)                     = (*(s_Ptr) ^ (unsigned long)(s_Color & 0x00ffffff)) | (*(s_Ptr) & 0xff000000);
  ((unsigned char *)s_Ptr)    += (s_HANDLE_GDC->ResX * 3);  
 }   
}

void __GDC_XORVLine_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2)
{
 register unsigned long *s_Ptr = (unsigned long *)(((char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x]);
 while(s_y1++ <= s_y2)
 {
  *(s_Ptr)                         ^= (unsigned long)s_Color;
  ((unsigned char *)s_Ptr)         += (s_HANDLE_GDC->ResX <<2);  
 }   
}
inline void GDC_XORVLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_y1, &s_y2);
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y1); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y2);
 _GDC_XORVLine[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Color, s_x, s_y1, s_y2);
}

void __GDC_GetBox_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = s_x2 - s_x1 + 1;  
 register unsigned char *s_Ptr = (((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_y1++ <= s_y2) 
 {  
  memcpy(s_Buffer, s_Ptr, s_Range);   
  ((unsigned char *)s_Buffer) += s_Range;
  s_Ptr                       += s_HANDLE_GDC->ResX;
 }
}    
   
void __GDC_GetBox_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = (s_x2 - s_x1 + 1) << 1/* s_HANDLE_GDC->ResBytes */;
 register unsigned short *s_Ptr = (unsigned short *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_y1++ <= s_y2)
 {
  memcpy(s_Buffer, s_Ptr, s_Range);
  ((unsigned char *)s_Buffer) += s_Range;
  s_Ptr                       += s_HANDLE_GDC->ResX;  
 } 
}

void __GDC_GetBox_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = (s_x2 - s_x1 + 1) * 3/* s_HANDLE_GDC->ResBytes */;
 register unsigned char *s_Ptr = (((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_y1++ <= s_y2)
 {
  memcpy(s_Buffer, s_Ptr, s_Range);
  ((unsigned char *)s_Buffer) += s_Range;
  s_Ptr                       += (s_HANDLE_GDC->ResX * 3/* s_HANDLE_GDC->ResBytes */);  
 } 
}

void __GDC_GetBox_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = (s_x2 - s_x1 + 1) << 2/* s_HANDLE_GDC->ResBytes */; 
 register unsigned long *s_Ptr = (unsigned long *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_y1++ <= s_y2)
 {
  memcpy(s_Buffer, s_Ptr, s_Range);
  ((unsigned char *)s_Buffer) += s_Range;
  s_Ptr                       += s_HANDLE_GDC->ResX;  
 } 
}

inline void GDC_GetBox(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_x1, &s_x2); __GDC_CheckSwap(&s_y1, &s_y2);
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x1); __GDC_CheckLimitX(s_HANDLE_GDC, &s_x2);
 __GDC_CheckLimitY(s_HANDLE_GDC, &s_y1); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y2);
 _GDC_GetBox[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Buffer, s_x1, s_y1, s_x2, s_y2); 
}

void __GDC_SetBox_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = s_x2 - s_x1 + 1;  
 register unsigned char *s_Ptr = (((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_y1++ <= s_y2) 
 {  
  memcpy(s_Ptr, s_Buffer, s_Range);   
  ((unsigned char *)s_Buffer) += s_Range;
  s_Ptr                       += s_HANDLE_GDC->ResX;
 }
}

void __GDC_SetBox_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = (s_x2 - s_x1 + 1) << 1/* s_HANDLE_GDC->ResBytes */;
 register unsigned short *s_Ptr = (unsigned short *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_y1++ <= s_y2)
 {
  memcpy(s_Ptr, s_Buffer, s_Range);
  ((unsigned char *)s_Buffer) += s_Range;
  s_Ptr                       += s_HANDLE_GDC->ResX;  
 } 
}

void __GDC_SetBox_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = (s_x2 - s_x1 + 1) * 3/* s_HANDLE_GDC->ResBytes */;
 register unsigned char *s_Ptr = (((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_y1++ <= s_y2)
 {
  memcpy(s_Ptr, s_Buffer, s_Range);
  ((unsigned char *)s_Buffer) += s_Range;
  s_Ptr                       += (s_HANDLE_GDC->ResX * 3/* s_HANDLE_GDC->ResBytes */);  
 } 
}
    
void __GDC_SetBox_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = (s_x2 - s_x1 + 1) << 2/* s_HANDLE_GDC->ResBytes */; 
 register unsigned long *s_Ptr = (unsigned long *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_y1++ <= s_y2)
 {
  memcpy(s_Ptr, s_Buffer, s_Range);
  ((unsigned char *)s_Buffer) += s_Range;
  s_Ptr                       += s_HANDLE_GDC->ResX;  
 } 
}

inline void GDC_SetBox(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_x1, &s_x2); __GDC_CheckSwap(&s_y1, &s_y2);
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x1); __GDC_CheckLimitX(s_HANDLE_GDC, &s_x2);
 __GDC_CheckLimitY(s_HANDLE_GDC, &s_y1); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y2);
 _GDC_SetBox[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Buffer, s_x1, s_y1, s_x2, s_y2); 
}

void __GDC_DrawBox_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = (s_x2 - s_x1 + 1);  
 register unsigned char *s_Ptr = (((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 while(s_y1++ <= s_y2) 
 {  
  memset(s_Ptr, s_Color, s_Range);   
  s_Ptr                       += s_HANDLE_GDC->ResX;
 }
}

void __GDC_DrawBox_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = (s_x2 - s_x1 + 1);
 register unsigned short *s_Ptr = (unsigned short *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 int s_CountX;
 while(s_y1++ <= s_y2)
 {
  for(s_CountX = 0;s_CountX < s_Range;s_CountX++)
  { 
   *(((unsigned short *)s_Ptr)+s_CountX) = (unsigned short)s_Color; 
  }
  s_Ptr                       += s_HANDLE_GDC->ResX;  
 } 
}

void __GDC_DrawBox_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = (s_x2 - s_x1 + 1);
 register unsigned long *s_Ptr = (unsigned long *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 int s_CountX;
 register unsigned long *s_TPtr;
 while(s_y1++ <= s_y2)
 {
  for(s_CountX = 0;s_CountX < s_Range;s_CountX++)
  {
   s_TPtr = (unsigned long *)(((unsigned char *)s_Ptr)+(s_CountX * 3/* s_HANDLE_GDC->ResBytes */));   
   *(s_TPtr) = (unsigned long)(s_Color&0x00ffffff) | ((*(s_TPtr)) & 0xff000000); 
  }
  ((unsigned char *)s_Ptr)+= s_HANDLE_GDC->ResX * 3/* s_HANDLE_GDC->ResBytes */;  
 }  
}

void __GDC_DrawBox_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = (s_x2 - s_x1 + 1);
 register unsigned long *s_Ptr = (unsigned long *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 int s_CountX;
 while(s_y1++ <= s_y2)
 {
  for(s_CountX = 0;s_CountX < s_Range;s_CountX++)
  { 
   *(((unsigned long *)s_Ptr)+s_CountX) = (unsigned long)s_Color; 
  }
  s_Ptr                       += s_HANDLE_GDC->ResX;
 }  
}

inline void GDC_DrawBox(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_x1, &s_x2); __GDC_CheckSwap(&s_y1, &s_y2);
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x1); __GDC_CheckLimitX(s_HANDLE_GDC, &s_x2);
 __GDC_CheckLimitY(s_HANDLE_GDC, &s_y1); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y2);
 _GDC_DrawBox[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Color, s_x1, s_y1, s_x2, s_y2); 
}

void __GDC_XORBox_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = (s_x2 - s_x1 + 1);  
 register unsigned char *s_Ptr = (((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 int s_CountX;
 while(s_y1++ <= s_y2) 
 {  
  for(s_CountX = 0;s_CountX < s_Range;s_CountX++)
  { 
   *(((unsigned char *)s_Ptr)+s_CountX) ^= (unsigned char)s_Color; 
  }
  s_Ptr                       += s_HANDLE_GDC->ResX;
 }
}

void __GDC_XORBox_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = (s_x2 - s_x1 + 1);
 register unsigned short *s_Ptr = (unsigned short *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 int s_CountX;
 while(s_y1++ <= s_y2)
 {
  for(s_CountX = 0;s_CountX < s_Range;s_CountX++)
  { 
   *(((unsigned short *)s_Ptr)+s_CountX) ^= (unsigned short)s_Color; 
  }
  s_Ptr                       += s_HANDLE_GDC->ResX;  
 } 
}

void __GDC_XORBox_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = (s_x2 - s_x1 + 1);
 register unsigned long *s_Ptr = (unsigned long *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 int s_CountX;
 register unsigned long *s_TPtr;
 while(s_y1++ <= s_y2)
 {
  for(s_CountX = 0;s_CountX < s_Range;s_CountX++)
  {
   s_TPtr = (unsigned long *)(((unsigned char *)s_Ptr)+(s_CountX * 3/* s_HANDLE_GDC->ResBytes */));   
   *(s_TPtr) = (*(s_TPtr) ^ (unsigned long)(s_Color&0x00ffffff)) | ((*(s_TPtr)) & 0xff000000); 
  }
  ((unsigned char *)s_Ptr)+= s_HANDLE_GDC->ResX * 3/* s_HANDLE_GDC->ResBytes */;  
 }  
}

void __GDC_XORBox_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Range = (s_x2 - s_x1 + 1);
 register unsigned long *s_Ptr = (unsigned long *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y1] + s_HANDLE_GDC->OffsetX[s_x1]);
 int s_CountX;
 while(s_y1++ <= s_y2)
 {
  for(s_CountX = 0;s_CountX < s_Range;s_CountX++)
  { 
   *(((unsigned long *)s_Ptr)+s_CountX) ^= (unsigned long)s_Color; 
  }
  s_Ptr                       += s_HANDLE_GDC->ResX;
 }  
}

inline void GDC_XORBox(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_x1, &s_x2); __GDC_CheckSwap(&s_y1, &s_y2);
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x1); __GDC_CheckLimitX(s_HANDLE_GDC, &s_x2);
 __GDC_CheckLimitY(s_HANDLE_GDC, &s_y1); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y2);
 _GDC_XORBox[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Color, s_x1, s_y1, s_x2, s_y2); 
}

void *__GDC_GetLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y)
{
 *(((unsigned char *)s_Buffer)++) = *(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x]);
 return((void *)s_Buffer);
}

void *__GDC_GetLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y)
{
 *(((unsigned short *)s_Buffer)++) = *((unsigned short *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x]));
 return((void *)s_Buffer);
}

void *__GDC_GetLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y)
{
 unsigned long *s_Ptr = ((unsigned long *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x]));
 *((unsigned long *)s_Buffer) = (*(s_Ptr) | 0x00ffffff)  | (*((unsigned long *)s_Buffer) & 0xff000000);
 ((unsigned char *)s_Buffer) += 3/* s_HANDLE_GDC->ResBytes */; 
 return((void *)s_Buffer);
}

void *__GDC_GetLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y)
{
 *(((unsigned long *)s_Buffer)++) = *((unsigned long *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x]));
 return((void *)s_Buffer);
}

void GDC_GetLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_GreatDelta, s_DeltaX, s_DeltaY, s_sx, s_sy, s_Count, s_StepX, s_StepY;
 DEF_GDC_AUTOINIT();   
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x1); __GDC_CheckLimitX(s_HANDLE_GDC, &s_x2);
 __GDC_CheckLimitY(s_HANDLE_GDC, &s_y1); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y2);
 s_DeltaX = s_x2 - s_x1; s_DeltaY = s_y2 - s_y1;                            
 if((s_DeltaX==0)&&(s_DeltaY==0))
 {
  _GDC_GetLine[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Buffer, s_x1, s_y1); 
  return;
 } 
 else if(s_DeltaY==0)
 {
  GDC_GetHLine(s_HANDLE_GDC, s_Buffer, s_x1, s_x2, s_y1);                   
  return;
 } 
 else if(s_DeltaX==0)
 {
  GDC_GetVLine(s_HANDLE_GDC, s_Buffer, s_x1, s_y1, s_y2);                   
  return;
 }
 else                                                                       
 {
  if(s_DeltaX >= 0)s_StepX = 1;
  else s_StepX = (-1);
  if(s_DeltaY >= 0)s_StepY = 1;
  else s_StepY = (-1);
  s_DeltaX = (s_DeltaX>=0)?s_DeltaX:(s_DeltaX*(-1));
  s_DeltaY = (s_DeltaY>=0)?s_DeltaY:(s_DeltaY*(-1));
  if(s_DeltaX >= s_DeltaY)s_GreatDelta = s_DeltaX;
  else s_GreatDelta = s_DeltaY; 
  s_Count = s_sx = s_sy = 0;
  do
  {
   s_Buffer = _GDC_GetLine[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Buffer, s_x1, s_y1); 
   s_sx += s_DeltaX; s_sy += s_DeltaY;
   if(s_sx>=s_GreatDelta)
   {
    s_sx -= s_GreatDelta;  
    s_x1 += s_StepX;
   }
   if(s_sy>=s_GreatDelta)
   {
    s_sy -= s_GreatDelta;  
    s_y1 += s_StepY; 
   }
  }while(s_Count++<s_GreatDelta); 
 }
}

void *__GDC_SetLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y)
{
 *(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x]) = *(((unsigned char *)s_Buffer)++);
 return((void *)s_Buffer);
}

void *__GDC_SetLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y)
{
 *((unsigned short *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x])) = *(((unsigned short *)s_Buffer)++);
 return((void *)s_Buffer);
}

void *__GDC_SetLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y)
{
 unsigned long *s_Ptr = ((unsigned long *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x]));
 *(s_Ptr) = (*((unsigned long *)s_Buffer) | 0x00ffffff)  | (*(s_Ptr) & 0xff000000);
 ((unsigned char *)s_Buffer) += 3/* s_HANDLE_GDC->ResBytes */; 
 return((void *)s_Buffer);
}

void *__GDC_SetLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y)
{
 *((unsigned long *)(((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_y] + s_HANDLE_GDC->OffsetX[s_x])) = *(((unsigned long *)s_Buffer)++);
 return((void *)s_Buffer);
}

void GDC_SetLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_GreatDelta, s_DeltaX, s_DeltaY, s_sx, s_sy, s_Count, s_StepX, s_StepY;
 DEF_GDC_AUTOINIT();   
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x1); __GDC_CheckLimitX(s_HANDLE_GDC, &s_x2);
 __GDC_CheckLimitY(s_HANDLE_GDC, &s_y1); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y2);
 s_DeltaX = s_x2 - s_x1; s_DeltaY = s_y2 - s_y1;                            
 if((s_DeltaX==0)&&(s_DeltaY==0))
 {
  _GDC_SetLine[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Buffer, s_x1, s_y1);
  return;
 } 
 else if(s_DeltaY==0)
 {
  GDC_SetHLine(s_HANDLE_GDC, s_Buffer, s_x1, s_x2, s_y1);                   
  return;
 } 
 else if(s_DeltaX==0)
 {
  GDC_SetVLine(s_HANDLE_GDC, s_Buffer, s_x1, s_y1, s_y2);                   
  return;
 }
 else                                                                       
 {
  if(s_DeltaX >= 0)s_StepX = 1;
  else s_StepX = (-1);
  if(s_DeltaY >= 0)s_StepY = 1;
  else s_StepY = (-1);
  s_DeltaX = (s_DeltaX>=0)?s_DeltaX:(s_DeltaX*(-1));
  s_DeltaY = (s_DeltaY>=0)?s_DeltaY:(s_DeltaY*(-1));
  if(s_DeltaX >= s_DeltaY)s_GreatDelta = s_DeltaX;
  else s_GreatDelta = s_DeltaY; 
  s_Count = s_sx = s_sy = 0;
  do
  {
   s_Buffer = _GDC_SetLine[s_HANDLE_GDC->ResBytes - 1](s_HANDLE_GDC, s_Buffer, s_x1, s_y1);
   s_sx += s_DeltaX; s_sy += s_DeltaY;
   if(s_sx>=s_GreatDelta)
   {
    s_sx -= s_GreatDelta;  
    s_x1 += s_StepX;
   }
   if(s_sy>=s_GreatDelta)
   {
    s_sy -= s_GreatDelta;  
    s_y1 += s_StepY; 
   }
  }while(s_Count++<s_GreatDelta); 
 }
}

void GDC_DrawLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2)
{ 
/*
 �귡���� �˰������� ������ �������� �˰�����...~~~ Ȯ���� �����Ŷ� ����...
*/
 int s_GreatDelta, s_DeltaX, s_DeltaY, s_sx, s_sy, s_Count, s_StepX, s_StepY;
 DEF_GDC_AUTOINIT();   
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x1); __GDC_CheckLimitX(s_HANDLE_GDC, &s_x2);
 __GDC_CheckLimitY(s_HANDLE_GDC, &s_y1); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y2);
 s_DeltaX = s_x2 - s_x1; s_DeltaY = s_y2 - s_y1;                            
 if((s_DeltaX==0)&&(s_DeltaY==0))
 {
  GDC_DrawPixel(s_HANDLE_GDC, s_Color, s_x1, s_y1);   
  return;
 } 
 else if(s_DeltaY==0)
 {
  GDC_DrawHLine(s_HANDLE_GDC, s_Color, s_x1, s_x2, s_y1);                   
  return;
 } 
 else if(s_DeltaX==0)
 {
  GDC_DrawVLine(s_HANDLE_GDC, s_Color, s_x1, s_y1, s_y2);                   
  return;
 }
 else                                                                       
 {
  if(s_DeltaX >= 0)s_StepX = 1;
  else s_StepX = (-1);
  if(s_DeltaY >= 0)s_StepY = 1;
  else s_StepY = (-1);
  s_DeltaX = (s_DeltaX>=0)?s_DeltaX:(s_DeltaX*(-1));
  s_DeltaY = (s_DeltaY>=0)?s_DeltaY:(s_DeltaY*(-1));
  if(s_DeltaX >= s_DeltaY)s_GreatDelta = s_DeltaX;
  else s_GreatDelta = s_DeltaY; 
  s_Count = s_sx = s_sy = 0;
  do
  {
   GDC_DrawPixel(s_HANDLE_GDC, s_Color, s_x1, s_y1);
   s_sx += s_DeltaX; s_sy += s_DeltaY;
   if(s_sx>=s_GreatDelta)
   {
    s_sx -= s_GreatDelta;  
    s_x1 += s_StepX;
   }
   if(s_sy>=s_GreatDelta)
   {
    s_sy -= s_GreatDelta;  
    s_y1 += s_StepY; 
   }
  }while(s_Count++<s_GreatDelta); 
 }
}

inline void GDC_Bitmap8x16(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_Color, int s_BackColor, int s_x, int s_y)
{
 register int s_x1, s_y1, s_Bit, s_xx, s_yy;
 // DEF_GDC_AUTOINIT();   
 for(s_y1 = 0;s_y1 < 16;s_y1++)
 {
  s_yy = s_y + (s_y1 * s_HANDLE_GDC->FontScaleY);
  for(s_x1 = 0, s_Bit = 0x80;s_x1 < 8;s_x1++, s_Bit >>= 1)
  {
   s_xx = s_x + (s_x1 * s_HANDLE_GDC->FontScaleX);
   if(s_Bit & *(((unsigned char *)s_Buffer)+s_y1))
   { // Color
    if(s_Color!=(-1))
    {
     GDC_DrawBox(s_HANDLE_GDC, s_Color, s_xx, s_yy, s_xx + s_HANDLE_GDC->FontScaleX - 1, s_yy + s_HANDLE_GDC->FontScaleY - 1); 
    } 
   }
   else if(s_BackColor!=(-1))
   { // BackColor
    if(s_Color!=(-1))
    {
     GDC_DrawBox(s_HANDLE_GDC, s_BackColor, s_xx, s_yy, s_xx + s_HANDLE_GDC->FontScaleX - 1, s_yy + s_HANDLE_GDC->FontScaleY - 1); 
    }
   }  
  }  
 } 
}

inline void GDC_Bitmap16x16(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_Color, int s_BackColor, int s_x, int s_y)
{
 register unsigned int s_Bit, s_CountY, s_CountX; 
 // DEF_GDC_AUTOINIT();   
 for(s_CountY = s_y;s_CountY < (s_y + (s_HANDLE_GDC->FontScaleY << 4));s_CountY+=s_HANDLE_GDC->FontScaleY, ((unsigned short *)s_Buffer)++)
 {
  for(s_Bit = 0, s_CountX = (s_x + ((s_HANDLE_GDC->FontScaleX << 4) - s_HANDLE_GDC->FontScaleX));s_Bit < 16;s_Bit++, s_CountX -= s_HANDLE_GDC->FontScaleX)
  {
   if(*((unsigned short *)s_Buffer) & (1<<s_Bit))GDC_DrawBox(s_HANDLE_GDC, s_Color, s_CountX, s_CountY, s_CountX + (s_HANDLE_GDC->FontScaleX-1), s_CountY + (s_HANDLE_GDC->FontScaleY - 1));
   else if(s_BackColor != (-1))GDC_DrawBox(s_HANDLE_GDC, s_BackColor, s_CountX, s_CountY, s_CountX + (s_HANDLE_GDC->FontScaleX-1), s_CountY + (s_HANDLE_GDC->FontScaleY - 1));
  }   
 } 
}
    
inline void GDC_DrawEnglish(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, int s_Character, int s_x, int s_y)
{
 DEF_GDC_AUTOINIT();   
 GDC_Bitmap8x16(s_HANDLE_GDC, &g_Font08[(s_Character & 0x00ff)<<4], s_Color, s_BackColor, s_x, s_y);
}

void GDC_DrawHangul(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, int s_Character, int s_x, int s_y)
{
 unsigned short s_c0, s_c1, s_c2, s_b0, s_b1, s_b2, s_Count;
 unsigned char s_Buffer[32];
 // DEF_GDC_AUTOINIT();   
 s_Character &= 0xffff;
 s_c0 = (unsigned short)g_HAN_table0[(s_Character >> 0x0a) & 0x1f] & 0xff; // �ʼ� 5bit
 s_c1 = (unsigned short)g_HAN_table1[(s_Character >> 0x05) & 0x1f] & 0xff; // �߼� 5bit
 s_c2 = (unsigned short)g_HAN_table2[(s_Character        ) & 0x1f] & 0xff; // ���� 5bit
 if(s_c2 == 0x00ff) // ������ ���� ���
 {
  s_b0 = (unsigned short)g_HAN_ftable0[s_c1]; // ������ ���� ��� �ʼ�
  if(s_c0 == 0 || s_c0 == 0x000f)s_b1 = 0;    // Ư���� �ʼ��� ��쿡 ���� �߼� ��
  else s_b1 = 1;                              
  s_b2 = 0;  
 }
 else               // ������ �ִ� ���
 {
  s_b0 = (unsigned short)g_HAN_ftable1[s_c1]; // ������ ���� ��� �ʼ� ��
  if(s_c0 == 0 || s_c0 == 0x000f)s_b1 = 2;
  else s_b1 = 3;
  s_b2 = (unsigned short)g_HAN_ltable[s_c1];  // �߼��� ���� �������� ���� 
 }
 for(s_Count = 0;s_Count < 32;s_Count+=2)
 {
  s_Buffer[s_Count] = s_Buffer[s_Count + 1] = 0;
  if(s_c0 != 0xff)
  {
   s_Buffer[s_Count] |= g_Font16[(s_b0 * 19 * 32) + (s_c0 * 32) + (s_Count+1) + 0];   
   s_Buffer[s_Count+1] |= g_Font16[(s_b0 * 19 * 32) + (s_c0 * 32) + (s_Count) + 0];   
  }
  if(s_c1 != 0xff)
  {
   s_Buffer[s_Count] |= g_Font16[(s_b1 * 21 * 32) + (s_c1 * 32) + (s_Count+1) + 4864];   
   s_Buffer[s_Count+1] |= g_Font16[(s_b1 * 21 * 32) + (s_c1 * 32) + (s_Count) + 4864];   
  }
  if(s_c2 != 0xff)
  {
   s_Buffer[s_Count] |= g_Font16[(s_b2 * 27 * 32) + (s_c2 * 32) + (s_Count+1) + 4864 + 2688];   
   s_Buffer[s_Count+1] |= g_Font16[(s_b2 * 27 * 32) + (s_c2 * 32) + (s_Count) + 4864 + 2688];   
  }
 }
 GDC_Bitmap16x16(s_HANDLE_GDC, &s_Buffer[0], s_Color, s_BackColor, s_x, s_y);
}

inline void GDC_GetFontSize(t_GDC *s_HANDLE_GDC, int *s_SizeX, int *s_SizeY)
{
 DEF_GDC_AUTOINIT();   
 if(s_SizeX)*(s_SizeX) = s_HANDLE_GDC->FontScaleX;
 if(s_SizeY)*(s_SizeY) = s_HANDLE_GDC->FontScaleY; 
}

inline void GDC_SetFontSize(t_GDC *s_HANDLE_GDC, int s_SizeX, int s_SizeY)
{
 DEF_GDC_AUTOINIT();   
 s_HANDLE_GDC->FontScaleX = s_SizeX;
 s_HANDLE_GDC->FontScaleY = s_SizeY; 
}

inline void GDC_ClearScreen(t_GDC *s_HANDLE_GDC, int s_Color)
{
 DEF_GDC_AUTOINIT();   
 GDC_DrawBox(s_HANDLE_GDC, s_Color, s_HANDLE_GDC->Clipping[0], s_HANDLE_GDC->Clipping[1], s_HANDLE_GDC->Clipping[2], s_HANDLE_GDC->Clipping[3]);    
}

inline void GDC_ConvertKStoJO(unsigned short *s_HangulCode)
{ // �ϼ����� ���������� �ٲٴ� ��ȯ�ڵ� - ���������δ� �������� �ξ� ���ϴ�.
 register unsigned short s_CH, s_CL;
 // DEF_GDC_AUTOINIT();   
 s_CH = (*(s_HangulCode) >> 8) & 0xff; 
 s_CL = (*(s_HangulCode)     ) & 0xff;
 if(s_CL < 0xb0 || s_CL > 0xc8 || s_CH < 0xa1 || s_CH > 0xfe) *(s_HangulCode) = 0x2020;
 else 
 {
  if(s_CL == 0xa4)
  {
   if(s_CH >= 0xa1 && s_CH <= 0xd3)*(s_HangulCode) = g_HAN_SingleTable[s_CH - 0xa1]; 
   else *(s_HangulCode) = 0x2020;
  }
  else *(s_HangulCode) = g_HAN_KSTable[((s_CL - 0xb0) * 94) + (s_CH - 0xa1)];  
 } 
}

void GDC_DrawPutsEnglish(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, void *s_String, int s_x, int s_y)
{
 int s_sx = s_x;    
 DEF_GDC_AUTOINIT();   
 while((s_x + (s_HANDLE_GDC->FontScaleX<<3)) < 0 && *((unsigned char *)s_String) != '\0')
 {
  ((unsigned char *)s_String)++;
  s_x += (s_HANDLE_GDC->FontScaleX<<3);
 }
 while(*((unsigned char *)s_String))
 {
  if(*((unsigned char *)s_String) == '\n')
  {
   ((unsigned char *)s_String)++;
   s_x = s_sx;
   s_y += (16 * s_HANDLE_GDC->FontScaleX);
  }   
  else 
  {
   GDC_DrawEnglish(s_HANDLE_GDC, s_Color, s_BackColor, *(((unsigned char *)s_String)++), s_x, s_y);  
   s_x += (s_HANDLE_GDC->FontScaleX << 3);
  }
  if(s_HANDLE_GDC->ResX >= s_x)break;
 }  
}

void GDC_DrawPutsHangul(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, void *s_String, int s_x, int s_y)
{
 int s_sx = s_x;    
 DEF_GDC_AUTOINIT();   
 while((s_x + ((s_HANDLE_GDC->FontScaleX<<3)<<1)) < 0 && *((unsigned char *)s_String) != '\0')
 {
  if(*((unsigned char *)s_String) & 0x80) // �ѱ��� ���
  {
   ((unsigned char *)s_String)+=2;
   s_x += (s_HANDLE_GDC->FontScaleX<<3)<<1;
  }
  else
  {
   ((char *)s_String)++;
   s_x += (s_HANDLE_GDC->FontScaleX<<3);
  }
 }
 while(*((unsigned char *)s_String))
 {
  if(*((unsigned char *)s_String) == '\n')
  {
   ((unsigned char *)s_String)++;
   s_x = s_sx;
   s_y += (16 * s_HANDLE_GDC->FontScaleX);
  }
  else
  {  
   if(*((unsigned char *)s_String) & 0x80) // �ѱ��� ���
   {
    unsigned short s_Jo = *(((unsigned short *)s_String)++);   
    GDC_ConvertKStoJO(&s_Jo);
    GDC_DrawHangul(s_HANDLE_GDC, s_Color, s_BackColor, s_Jo, s_x, s_y);
    s_x += (s_HANDLE_GDC->FontScaleX << 4); 
   }   
   else 
   {
    GDC_DrawEnglish(s_HANDLE_GDC, s_Color, s_BackColor, *(((unsigned char *)s_String)++), s_x, s_y);
    s_x += (s_HANDLE_GDC->FontScaleX << 3); 
   }
  }
  if(s_HANDLE_GDC->ResX >= s_x)break;
 }
}

void GDC_DrawPrintfEnglish(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, int s_x, int s_y, void *s_FormatString, ...)
{
 va_list s_VArg;
 void *s_String = (void *)malloc((s_HANDLE_GDC->ResX >> 3) << 1);
 DEF_GDC_AUTOINIT();   
 if(s_String)
 {
  va_start(s_VArg, s_FormatString);
  vsprintf(s_String, s_FormatString, s_VArg);
  va_end(s_VArg);
  GDC_DrawPutsEnglish(s_HANDLE_GDC, s_Color, s_BackColor, s_String, s_x, s_y); 
  free(s_String); 
 } 
}

void GDC_DrawPrintfHangul(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, int s_x, int s_y, void *s_FormatString, ...)
{
 va_list s_VArg;
 void *s_String = (void *)malloc((s_HANDLE_GDC->ResX >> 3) << 1);
 DEF_GDC_AUTOINIT();   
 if(s_String)
 {
  va_start(s_VArg, s_FormatString);
  vsprintf(s_String, s_FormatString, s_VArg);
  va_end(s_VArg);
  GDC_DrawPutsHangul(s_HANDLE_GDC, s_Color, s_BackColor, s_String, s_x, s_y); 
  free(s_String);  
 } 
}

inline void GDC_DrawRec3D(t_GDC *s_HANDLE_GDC, int s_LColor, int s_RColor, int s_x1, int s_y1, int s_x2, int s_y2)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_x1, &s_x2); __GDC_CheckSwap(&s_y1, &s_y2);
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x1); __GDC_CheckLimitX(s_HANDLE_GDC, &s_x2);
 __GDC_CheckLimitY(s_HANDLE_GDC, &s_y1); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y2);
 GDC_DrawHLine(s_HANDLE_GDC, s_LColor, s_x1, s_x2, s_y1);    
 GDC_DrawHLine(s_HANDLE_GDC, s_RColor, s_x1 + 1, s_x2, s_y2); 
 GDC_DrawVLine(s_HANDLE_GDC, s_LColor, s_x1, s_y1 + 1, s_y2); 
 GDC_DrawVLine(s_HANDLE_GDC, s_RColor, s_x2, s_y1 + 1, s_y2 - 1); 
}

void GDC_DrawRectangle(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2)
{
 // DEF_GDC_AUTOINIT();   
 GDC_DrawRec3D(s_HANDLE_GDC, s_Color, s_Color, s_x1, s_y1, s_x2, s_y2);   
}

void GDC_DrawBox3D(t_GDC *s_HANDLE_GDC, int s_LColor, int s_RColor, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_x1, &s_x2); __GDC_CheckSwap(&s_y1, &s_y2);
 GDC_DrawRec3D(s_HANDLE_GDC, s_LColor, s_RColor, s_x1, s_y1, s_x2, s_y2);  
 if(s_x1 != s_x2)
 {
  s_x1++; s_x2--;  
 }
 if(s_y1 != s_y2)
 {
  s_y1++; s_y2--;  
 }
 GDC_DrawBox(s_HANDLE_GDC, s_Color, s_x1, s_y1, s_x2, s_y2); 
}

int GDC_Color(int s_Red, int s_Green, int s_Blue) /* 0 ~ 32, 0 ~ 64, 0 ~ 32 �ܰ� color (Direct RGB) */
{
 return((int)((unsigned int)(s_Red << 11) | (unsigned int)((s_Green<<1)<<5) | (unsigned int)(s_Blue))); /* 556 */    
}

int GDC_Color64(int s_Red, int s_Green, int s_Blue) /* 0 ~ 63 �ܰ� color */
{
 return( ((s_Red>>1)<<11) | (s_Green<<5) | (s_Blue>>1) );   
}

int GDC_Color256(int s_Red, int s_Green, int s_Blue) /* 0 ~ 255 �ܰ� color */
{
 return( ((s_Red>>3)<<11) | ((s_Green>>2)<<5) | ((s_Blue>>3)) ); 
}

void GDC_DrawButton(t_GDC *s_HANDLE_GDC, int s_Switch, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2)
{
 // DEF_GDC_AUTOINIT();   
 GDC_DrawRectangle(s_HANDLE_GDC, GDC_Color(0, 0, 0), s_x1, s_y1, s_x2, s_y2);
 if(s_Switch)GDC_DrawBox3D(s_HANDLE_GDC, GDC_Color(40, 40, 40), GDC_Color(63, 63, 63), s_Color, s_x1 + 1, s_y1 + 1, s_x2 - 1, s_y2 - 1); 
 else GDC_DrawBox3D(s_HANDLE_GDC, GDC_Color(63, 63, 63), GDC_Color(40, 40, 40), s_Color, s_x1 + 1, s_y1 + 1, s_x2 - 1, s_y2 - 1); 
}

int __GDC_GetMouse(t_GDC *s_HANDLE_GDC, int *s_x, int *s_y, int *s_Button)
{
 int s_Count, s_Return = 0;
 char *s_Buffer, s_Length = 3;
 char s_MouseBuffer[3];
 fd_set s_fdset; 
 struct timeval s_Time;
 DEF_GDC_AUTOINIT();   
 if(s_HANDLE_GDC->MouseHandle < 0)return(0);
 s_Buffer = &s_MouseBuffer[0];
 s_MouseBuffer[0] = s_MouseBuffer[1] = s_MouseBuffer[2] = 0;
 FD_ZERO(&s_fdset);
 FD_SET(s_HANDLE_GDC->MouseHandle, &s_fdset);
 s_Time.tv_sec = 0;
 s_Time.tv_usec = 1; // 1 us
 s_Count = select(s_HANDLE_GDC->MouseHandle + 1, &s_fdset, 0, 0, &s_Time);
 if(s_Count <= 0)return(s_Return);
 while(s_Length)
 {
  s_Count = read(s_HANDLE_GDC->MouseHandle, s_Buffer, s_Length);
  if(s_Count>0)
  {
   s_Return += s_Count;
   ((char *)s_Buffer)+=s_Count;
   s_Length -= s_Count; 
  }  
  if(s_Return % 3 == 0)break;
  FD_ZERO(&s_fdset);
  FD_SET(s_HANDLE_GDC->MouseHandle, &s_fdset);
  s_Time.tv_sec = 0;
  s_Time.tv_usec = 100 * 1000; // 100 * 1ms
  s_Count = select(s_HANDLE_GDC->MouseHandle + 1, &s_fdset, 0, 0, &s_Time);
  if(s_Count <= 0)break;  
 }
 if(s_Return == 3)
 {
  if(s_Button)*(s_Button) = (int)(s_MouseBuffer[0]);  
  if(s_x)*(s_x)      = (int)(s_MouseBuffer[1]); 
  if(s_y)*(s_y)      = (int)(s_MouseBuffer[2] * (-1));
  if(abs(*(s_x)) > 4) *(s_x) *= 2;
  if(abs(*(s_y)) > 4) *(s_y) *= 2;
 }
 return(s_Return);
}

int GDC_OpenMouse(t_GDC *s_HANDLE_GDC, void (*s_MouseEvent)(struct ts_GDC *))
{
 char *s_DeviceNames[] = { /* Auto select device-driver */
        "/dev/mouse",
	"/dev/psaux",
	(char *)0
       };   
 int s_HANDLE_Mouse = (-1);
 int s_Index = 0;
 DEF_GDC_AUTOINIT();   
 while(s_DeviceNames[s_Index])
 {
  s_HANDLE_Mouse = open(s_DeviceNames[s_Index++], O_RDONLY);
  if(s_HANDLE_Mouse >= 0)
  {
   s_HANDLE_GDC->MouseHandle = s_HANDLE_Mouse;
   s_HANDLE_GDC->MouseEvent  = s_MouseEvent;
   s_HANDLE_GDC->MouseX      = s_HANDLE_GDC->ResX >> 1;
   s_HANDLE_GDC->MouseY      = s_HANDLE_GDC->ResY >> 1;
   s_HANDLE_GDC->MouseButton = 0;   
   s_HANDLE_GDC->UseMouseCursor = 1; 
   GDC_MouseCursor(s_HANDLE_GDC, 1);  
   break;
  }
 }
 return(s_HANDLE_Mouse); 
}

void GDC_CloseMouse(t_GDC *s_HANDLE_GDC)
{
 DEF_GDC_AUTOINIT();   
 GDC_MouseCursor(s_HANDLE_GDC, 0);   
 if(s_HANDLE_GDC->MouseHandle >= 0)close(s_HANDLE_GDC->MouseHandle);   
 s_HANDLE_GDC->MouseHandle = (-1);
}

void GDC_MouseCursor(t_GDC *s_HANDLE_GDC, int s_Type)
{
 static unsigned long s_CursorBuffer[(16+4) * (16)] = {0,};    
 #if DEF_DEBUG_GDC == 1
  static char          s_String_DEBUG[20 + 1];
  static unsigned long s_CursorBuffer_DEBUG[161 * 16];
 #endif
 DEF_GDC_AUTOINIT();   
 if(s_Type > 0)
 {
  int s_CursorType1 = 0, s_CursorType2 = 1; 
  int s_x1 = s_HANDLE_GDC->MouseX, s_y1 = s_HANDLE_GDC->MouseY;
  int s_FontX, s_FontY;
  GDC_GetBox(s_HANDLE_GDC, &s_CursorBuffer[0], s_HANDLE_GDC->MouseX - 4, s_HANDLE_GDC->MouseY, s_HANDLE_GDC->MouseX + 15, s_HANDLE_GDC->MouseY + 15); 
  #if DEF_DEBUG_GDC == 1
   GDC_GetBox(s_HANDLE_GDC, &s_CursorBuffer_DEBUG[0], s_HANDLE_GDC->MouseX + 16, s_HANDLE_GDC->MouseY, s_HANDLE_GDC->MouseX + 160, s_HANDLE_GDC->MouseY + 15); 
  #endif
  switch(s_Type) /* Adjust location */
  {
   case 1:
        break;
   case 2:
        s_CursorType1 = 2; s_CursorType2 = 3; s_x1 -= 4;
        break;	
   default: 
	break; 	
  }
  GDC_GetFontSize(s_HANDLE_GDC, &s_FontX, &s_FontY); GDC_SetFontSize(s_HANDLE_GDC, 1, 1);
  #if DEF_DEBUG_GDC == 1
   sprintf(s_String_DEBUG, "%03d:%03d C%04X", s_HANDLE_GDC->MouseX, s_HANDLE_GDC->MouseY, GDC_GetPixel(s_HANDLE_GDC, s_HANDLE_GDC->MouseX, s_HANDLE_GDC->MouseY)); 
   GDC_DrawPutsEnglish(s_HANDLE_GDC, GDC_Color(42, 42, 42), (-1), s_String_DEBUG, s_HANDLE_GDC->MouseX + 16, s_HANDLE_GDC->MouseY);
  #endif
  GDC_Bitmap16x16(s_HANDLE_GDC, &g_MouseCursor[s_CursorType1][0], GDC_Color(0, 0, 0)      , (-1), s_x1, s_y1);
  GDC_Bitmap16x16(s_HANDLE_GDC, &g_MouseCursor[s_CursorType2][0], GDC_Color(63, 63, 63)   , (-1), s_x1, s_y1);
  GDC_SetFontSize(s_HANDLE_GDC, s_FontX, s_FontY);
 }
 else 
 {
  #if DEF_DEBUG_GDC == 1
   GDC_SetBox(s_HANDLE_GDC, &s_CursorBuffer_DEBUG[0], s_HANDLE_GDC->MouseX + 16, s_HANDLE_GDC->MouseY, s_HANDLE_GDC->MouseX + 160, s_HANDLE_GDC->MouseY + 15); 
  #endif
  GDC_SetBox(s_HANDLE_GDC, &s_CursorBuffer[0], s_HANDLE_GDC->MouseX - 4, s_HANDLE_GDC->MouseY, s_HANDLE_GDC->MouseX + 15, s_HANDLE_GDC->MouseY + 15); 
 }
}

void GDC_MouseProcess(t_GDC *s_HANDLE_GDC)
{
 int s_sx, s_sy, s_sb;
 DEF_GDC_AUTOINIT();   
 if(s_HANDLE_GDC->MouseHandle < 0)GDC_OpenMouse(s_HANDLE_GDC, NULL);
 if(__GDC_GetMouse(s_HANDLE_GDC, &s_sx, &s_sy, &s_sb) == 3)
 {
  if(s_HANDLE_GDC->UseMouseCursor == 1)GDC_MouseCursor(s_HANDLE_GDC, 0);   
  s_HANDLE_GDC->MouseX += s_sx; s_HANDLE_GDC->MouseY += s_sy;
  s_HANDLE_GDC->MouseButton = s_sb & 0x03;
  __GDC_CheckLimitX(s_HANDLE_GDC, &s_HANDLE_GDC->MouseX); __GDC_CheckLimitY(s_HANDLE_GDC, &s_HANDLE_GDC->MouseY);
  if(s_HANDLE_GDC->UseMouseCursor == 1)
  {
   if(s_HANDLE_GDC->MouseButton)GDC_MouseCursor(s_HANDLE_GDC, 2);
   else GDC_MouseCursor(s_HANDLE_GDC, 1);  
  }
  if(s_HANDLE_GDC->MouseEvent)s_HANDLE_GDC->MouseEvent(s_HANDLE_GDC);  
 } 
}

int GDC_MouseArea(t_GDC *s_HANDLE_GDC, int s_x1, int s_y1, int s_x2, int s_y2)
{
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_x1, &s_x2); __GDC_CheckSwap(&s_y1, &s_y2);
 s_x1 -= 16;
 s_y1 -= 16;
 return( ((s_HANDLE_GDC->MouseX >= s_x1) && (s_HANDLE_GDC->MouseX <= s_x2) && (s_HANDLE_GDC->MouseY >= s_y1) && (s_HANDLE_GDC->MouseY <= s_y2)) );    
}

int GDC_LoadJpeg(t_GDC *s_HANDLE_GDC, void *s_JpegName, int s_x, int s_y)
{
 int s_Return = 0;   
#if DEF_USE_JPEGLIB == 1
 struct jpeg_decompress_struct s_JpegInfo;
 struct jpeg_error_mgr         s_JpegError;
 JSAMPARRAY                    s_ImageBuffer;
 FILE                         *s_HANDLE_Jpeg;
 // struct timeb s_t1, s_t2;
 DEF_GDC_AUTOINIT();   
 // ftime(&s_t1);
 s_HANDLE_Jpeg = fopen(s_JpegName, "r");
 if(s_HANDLE_Jpeg)
 {
  int s_Row, s_LineY = 0, s_LineX;
#if DEF_USE_JPEGBUFFER == 1
  void *s_Buffer;
  int s_BufferIndex;
#else
  int s_sx, s_sy;
#endif
  s_JpegInfo.err = jpeg_std_error(&s_JpegError);
  jpeg_create_decompress(&s_JpegInfo);
  jpeg_stdio_src(&s_JpegInfo, s_HANDLE_Jpeg); 
  jpeg_read_header(&s_JpegInfo, TRUE);	   
  jpeg_calc_output_dimensions(&s_JpegInfo);
  s_Row = s_JpegInfo.output_width * s_JpegInfo.output_components; 
  s_ImageBuffer = (*s_JpegInfo.mem->alloc_sarray)((j_common_ptr)&s_JpegInfo, JPOOL_IMAGE, s_Row, 1);
  jpeg_start_decompress(&s_JpegInfo);
#if DEF_USE_JPEGBUFFER == 1
  s_Buffer = (void *)malloc(s_JpegInfo.output_width * s_JpegInfo.output_height * s_HANDLE_GDC->ResBytes);
  s_BufferIndex = 0;
#endif
  while(s_LineY < s_JpegInfo.output_height)
  {
   jpeg_read_scanlines(&s_JpegInfo, s_ImageBuffer, 1);   
#if DEF_USE_JPEGBUFFER == 1
   if(s_Buffer)
   { 
    for(s_LineX = 0; s_LineX < s_JpegInfo.output_width && (s_LineX + s_x) < s_HANDLE_GDC->ResX; s_LineX++)
    {
     *(((unsigned short *)s_Buffer) + s_BufferIndex++) = GDC_Color256(s_ImageBuffer[0][s_LineX * 3], s_ImageBuffer[0][(s_LineX * 3) + 1], s_ImageBuffer[0][(s_LineX * 3) + 2]);
    }
   }
#else
   s_sy = (s_LineY * s_HANDLE_GDC->FontScaleY) + s_y;   
   for(s_LineX = 0; s_LineX < s_JpegInfo.output_width; s_LineX++)
   {
    s_sx = (s_LineX * s_HANDLE_GDC->FontScaleX) + s_x;
    GDC_DrawBox(s_HANDLE_GDC, GDC_Color256(s_ImageBuffer[0][s_LineX * 3], s_ImageBuffer[0][(s_LineX * 3) + 1], s_ImageBuffer[0][(s_LineX * 3) + 2]), s_sx, s_sy, s_sx + (s_HANDLE_GDC->FontScaleX - 1), s_sy + (s_HANDLE_GDC->FontScaleY - 1)); 
   }
#endif
   s_LineY++;    
  }
#if DEF_USE_JPEGBUFFER == 1
  if(s_Buffer)
  {
   GDC_SetBox(s_HANDLE_GDC, s_Buffer, s_x, s_y, (s_x + s_JpegInfo.output_width) - 1, (s_y + s_JpegInfo.output_height) - 1);
   free(s_Buffer);
  }
#endif
  jpeg_finish_decompress(&s_JpegInfo); jpeg_destroy_decompress(&s_JpegInfo);
  s_Return++; fclose(s_HANDLE_Jpeg);
 }
 /*
 ftime(&s_t2);
 fprintf(stdout, "Start - %02d.%03d / %02d.%03d - DT=%02d.%03d\n", (int)s_t1.time, s_t1.millitm, (int)s_t2.time, s_t2.millitm, (int)(s_t2.time - s_t1.time), s_t2.millitm - s_t1.millitm);
 */
#endif
 return(s_Return);
}

int GDC_LoadGif(t_GDC *s_HANDLE_GDC, void *s_GifName, int s_x, int s_y)
{
 int s_Return = 0;
#if DEF_USE_GIFLIB == 1
 GifFileType *s_HANDLE_Gif = (GifFileType *)0;
 s_HANDLE_Gif = DGifOpenFileName((char *)s_GifName);
 if(s_HANDLE_Gif)
 {
  int s_ResolutionX, s_ResolutionY;
  int s_LineX, s_LineY;
  s_ResolutionX = s_HANDLE_Gif->SWidth;
  s_ResolutionY = s_HANDLE_Gif->SHeight;
  for(s_LineY = 0;s_LineY < s_ResolutionY;s_LineY++)
  {
   for(s_LineX = 0;s_LineX < s_ResolutionX;s_LineX++)
   {
    GDC_DrawPixel(s_HANDLE_GDC, DGifGetPixel(s_HANDLE_Gif, 0), s_LineX + s_x, s_LineY + s_y);
   }
  } 
  fprintf(stdout, "SWidth=%d, SHeight=%d, SResolution=%d, ImageCount=%d\n", 
          s_HANDLE_Gif->SWidth, s_HANDLE_Gif->SHeight, s_HANDLE_Gif->SColorResolution,
          s_HANDLE_Gif->ImageCount
         ); 
  


  DGifCloseFile(s_HANDLE_Gif);
  s_Return++;
 }
 // fprintf(stdout, "Gif load .....\n");
#endif 
 return(s_Return);
}

int GDC_Percent(int s_SMin, int s_SMax, int s_Current, int s_TMin, int s_TMax)
{
 int s_Return = (((s_TMax - s_TMin) * s_Current) / (s_SMax - s_SMin)) + s_TMin;
 return(s_Return); 
}

void GDC_UpdateBox(t_GDC *s_HANDLE_GDC, void *s_Source, void *s_Target, int s_x1, int s_y1, int s_x2, int s_y2) 
{
 register int s_x12;  
 DEF_GDC_AUTOINIT();   
 __GDC_CheckSwap(&s_x1, &s_x2); __GDC_CheckSwap(&s_y1, &s_y2);
 __GDC_CheckLimitX(s_HANDLE_GDC, &s_x1); __GDC_CheckLimitX(s_HANDLE_GDC, &s_x2);
 __GDC_CheckLimitY(s_HANDLE_GDC, &s_y1); __GDC_CheckLimitY(s_HANDLE_GDC, &s_y2);
 // disable(); - Do it ? Do!
 while(s_y1<=s_y2)
 {
  s_x12 = s_x1;
  while(s_x12<=s_x2)
  {
   if((unsigned short)GDC_GetPixel(s_HANDLE_GDC, s_x12, s_y1) == *(((unsigned short *)s_Target)))
   {
    GDC_DrawPixel(s_HANDLE_GDC, *((unsigned short *)s_Source), s_x12, s_y1);
   }
   s_x12++; ((short int *)s_Source)++; ((short int *)s_Target)++;
  } 
  s_y1++;
 }
 // enable(); - Do it ? Do!
}

void GDC_Scroll(t_GDC *s_HANDLE_GDC, int s_Arrow, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2, int s_Grid)
{
 int s_Count;   
 DEF_GDC_AUTOINIT();   
 switch(s_Arrow)
 {
  case 0:  // Left
       for(s_Count = s_x1; s_Count <= s_y2 - s_Grid; s_Count += s_Grid)
       {
       }
       break;   
  case 1:  // Top
       for(s_Count = s_y1; s_Count <= s_y2 - s_Grid; s_Count += s_Grid)
       {
	GDC_GetHLine(s_HANDLE_GDC, (((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_Count - s_Grid] + s_HANDLE_GDC->OffsetX[s_x1]), s_x1, s_x2, s_Count);  
       } 
       break;   
  case 2:  // Right
       break;   
  case 3:  // Bottom
       for(s_Count = s_y2 - s_Grid; s_Count >= s_y1; s_Count -= s_Grid)
       {
	GDC_GetHLine(s_HANDLE_GDC, (((unsigned char *)s_HANDLE_GDC->BaseAddress) + s_HANDLE_GDC->OffsetY[s_Count + s_Grid] + s_HANDLE_GDC->OffsetX[s_x1]), s_x1, s_x2, s_Count);  
       } 
       break;   
  default: break;
 }    
}

t_HANDLE_Keyboard *MZKEY_OPEN(const char *s_KeyboardDevice)
{ /* Reference from QT library */
 int s_HANDLE_TempKey;
 t_HANDLE_Keyboard *s_HANDLE_Keyboard = (t_HANDLE_Keyboard *)0;
 if(s_KeyboardDevice == (char *)0)s_KeyboardDevice = "/dev/tty";
 s_HANDLE_TempKey = open(s_KeyboardDevice, O_RDWR | O_NDELAY, 0);
 if(s_HANDLE_TempKey >= 0)
 {
  s_HANDLE_Keyboard = (t_HANDLE_Keyboard *)malloc(sizeof(t_HANDLE_Keyboard));
  if(s_HANDLE_Keyboard)
  {
   memset(s_HANDLE_Keyboard, 0, sizeof(t_HANDLE_Keyboard));
   s_HANDLE_Keyboard->BufferLength           = 256; 
   s_HANDLE_Keyboard->Buffer                 = (void *)malloc(s_HANDLE_Keyboard->BufferLength);
   s_HANDLE_Keyboard->InPtr                  = 0;
   s_HANDLE_Keyboard->OutPtr                 = 0;
   s_HANDLE_Keyboard->HANDLE                 = s_HANDLE_TempKey;
   tcgetattr(s_HANDLE_Keyboard->HANDLE, &s_HANDLE_Keyboard->OriginalTermios);
   tcgetattr(s_HANDLE_Keyboard->HANDLE, &s_HANDLE_Keyboard->NewTermios);
   ioctl(s_HANDLE_Keyboard->HANDLE, KDSKBMODE, K_RAW);
   s_HANDLE_Keyboard->NewTermios.c_iflag     = (IGNPAR | IGNBRK) & (~PARMRK) & (~ISTRIP);
   s_HANDLE_Keyboard->NewTermios.c_oflag     = 0;
   s_HANDLE_Keyboard->NewTermios.c_cflag     = CREAD | CS8;
   s_HANDLE_Keyboard->NewTermios.c_lflag     = 0;
   s_HANDLE_Keyboard->NewTermios.c_cc[VTIME] = 0;
   s_HANDLE_Keyboard->NewTermios.c_cc[VMIN]  = 1;
   cfsetispeed(&s_HANDLE_Keyboard->NewTermios, 9600);
   cfsetospeed(&s_HANDLE_Keyboard->NewTermios, 9600);
   tcsetattr(s_HANDLE_Keyboard->HANDLE, TCSANOW, &s_HANDLE_Keyboard->NewTermios);
  }
  else
  {
   fprintf(stderr, "Can not alloc memory for s_HANDLE_Keyboard !!!\n");
   close(s_HANDLE_TempKey); 
  }
 } 
 else fprintf(stderr, "Can not open device \"%s\"\n", s_KeyboardDevice);
/*
    signal(VTSWITCHSIG, vtSwitchHandler);

    struct vt_mode vtMode;
    ioctl(kbdFD, VT_GETMODE, &vtMode);

    // let us control VT switching
    vtMode.mode = VT_PROCESS;
    vtMode.relsig = VTSWITCHSIG;
    vtMode.acqsig = VTSWITCHSIG;
    ioctl(kbdFD, VT_SETMODE, &vtMode);

    struct vt_stat vtStat;
    ioctl(kbdFD, VT_GETSTATE, &vtStat);
    vtQws = vtStat.v_active;
*/
 return(s_HANDLE_Keyboard);
}

t_HANDLE_Keyboard *MZKEY_CLOSE(t_HANDLE_Keyboard *s_HANDLE_Keyboard)
{
 if(s_HANDLE_Keyboard)
 {
  tcsetattr(s_HANDLE_Keyboard->HANDLE, TCSANOW, &s_HANDLE_Keyboard->OriginalTermios);
  if(s_HANDLE_Keyboard->Buffer)free(s_HANDLE_Keyboard->Buffer);
  free(s_HANDLE_Keyboard);
  s_HANDLE_Keyboard = (t_HANDLE_Keyboard *)0;
 }
 return(s_HANDLE_Keyboard); 
}

void _MZKEY_PROCESS(t_HANDLE_Keyboard *s_HANDLE_Keyboard, unsigned char *s_Key)
{
 int s_NextPtr;
 s_NextPtr = s_HANDLE_Keyboard->InPtr + 1;
 if(s_NextPtr >= s_HANDLE_Keyboard->BufferLength)s_NextPtr = 0;
 if(s_NextPtr != s_HANDLE_Keyboard->OutPtr)
 {
  if(*(s_Key) == 224)
  {
   s_HANDLE_Keyboard->Flags |= 0x80; /* Set extended */
  }
  else
  {
   if(*(s_Key) & 0x80)
   {
    s_HANDLE_Keyboard->Flags |= 0x40; /* Set release */
    *(s_Key) &= 0x7f;
   } 
   *(((unsigned char *)s_HANDLE_Keyboard->Buffer) + s_HANDLE_Keyboard->InPtr) = *(s_Key);
   s_HANDLE_Keyboard->InPtr = s_NextPtr;
  }
 }
 else fprintf(stderr, "Out of keyboard buffer !!! (Buffer length: %d)\n", s_HANDLE_Keyboard->BufferLength); 
 s_HANDLE_Keyboard->Flags &= (/*0x80 |*/ /*0x40 |*/ 0x20 | 0x10 | 0x08 | 0x04 | 0x02 | 0x01);
}

int MZKEY_PROCESS(t_HANDLE_Keyboard *s_HANDLE_Keyboard)
{
 int s_Return = (-1), s_Count;
 if(s_HANDLE_Keyboard)
 { 
  unsigned char s_TempBuffer[0x80];
  s_Return = read(s_HANDLE_Keyboard->HANDLE, &s_TempBuffer[0], 0x80);
  for(s_Count = 0;s_Count < s_Return;s_Count++)_MZKEY_PROCESS(s_HANDLE_Keyboard, &s_TempBuffer[s_Count]); 
 }
 else fprintf(stderr, "Keyboard handle is null pointer !!!\n");
 return(s_Return); 
}

int MZKEY_READKEY(t_HANDLE_Keyboard *s_HANDLE_Keyboard)
{
 int s_Return = (-1);
 if(s_HANDLE_Keyboard)
 {
  int s_NextPtr;
  s_NextPtr = s_HANDLE_Keyboard->OutPtr + 1;
  if(s_NextPtr >= s_HANDLE_Keyboard->BufferLength)s_NextPtr=0;
  if(s_HANDLE_Keyboard->OutPtr != s_HANDLE_Keyboard->InPtr)
  {
   s_Return = *(((unsigned char *)s_HANDLE_Keyboard->Buffer) + s_HANDLE_Keyboard->OutPtr) & 0x7f; 
   s_HANDLE_Keyboard->OutPtr = s_NextPtr; 
  }
  /* else WAIT!!!!!!!!!! No key press */
 }
 /* else fprintf(stderr, "Keyboard handle is null pointer !!!\n"); */
 return(s_Return);
}

t_HANDLE_Keyboard *GDC_OpenKeyboard(t_GDC *s_HANDLE_GDC, char *s_DeviceName)
{
 t_HANDLE_Keyboard *s_HANDLE_Keyboard;
 s_HANDLE_Keyboard = MZKEY_OPEN(s_DeviceName);
 if(s_HANDLE_GDC && s_HANDLE_Keyboard)s_HANDLE_GDC->KeyboardHandle = s_HANDLE_Keyboard;
 return(s_HANDLE_Keyboard);
}

int GDC_KeyboardProcess(t_GDC *s_HANDLE_GDC)
{
 int s_Return;
 s_Return = MZKEY_PROCESS(s_HANDLE_GDC->KeyboardHandle);
 return(s_Return); 
}

int GDC_GetKey(t_GDC *s_HANDLE_GDC)
{
 return(MZKEY_READKEY(s_HANDLE_GDC->KeyboardHandle));
}

void GDC_CloseKeyboard(t_GDC *s_HANDLE_GDC)
{
 if(s_HANDLE_GDC->KeyboardHandle)s_HANDLE_GDC->KeyboardHandle = MZKEY_CLOSE(s_HANDLE_GDC->KeyboardHandle);
}

void GDC_Blender16(t_GDC *s_GDC, unsigned int s_AlphaR, unsigned int s_AlphaG, unsigned int s_AlphaB, int s_x1, int s_y1, int s_x2, int s_y2)
{
 unsigned int s_Seed[4];
 unsigned short *s_Buffer;
 s_Buffer = (unsigned short *)malloc((s_x2 - s_x1 + 1) * (s_y2 - s_y1 + 1) * s_GDC->ResBytes);
 if(s_Buffer)
 {
  int s_Count;
  GDC_GetBox(s_GDC, s_Buffer, s_x1, s_y1, s_x2, s_y2);   
  for(s_Count = 0;s_Count < ((s_x2 - s_x1 + 1) * (s_y2 - s_y1 + 1));s_Count++)
  {
   s_Seed[0] = *(s_Buffer + s_Count);
   s_Seed[1] = ((((s_Seed[0] >> 11) & 0x1f)<<3) * s_AlphaR) / 100;
   s_Seed[2] = ((((s_Seed[0] >> 5 ) & 0x3f)<<2) * s_AlphaG) / 100;
   s_Seed[3] = ((((s_Seed[0]      ) & 0x1f)<<3) * s_AlphaB) / 100;
   if(s_Seed[1] > 0xff)s_Seed[1] = 0xff;
   if(s_Seed[2] > 0xff)s_Seed[2] = 0xff;
   if(s_Seed[3] > 0xff)s_Seed[3] = 0xff;
   *(s_Buffer + s_Count) = GDC_Color256(s_Seed[1], s_Seed[2], s_Seed[3]);	       
  }
  GDC_SetBox(s_GDC, s_Buffer, s_x1, s_y1, s_x2, s_y2);   
  free(s_Buffer);
 }
}

void RGB_YCbCr(int s_Red, int s_Green, int s_Blue, int *s_Y, int *s_Cb, int *s_Cr)
{ /* ��ȯ�������� ���� �ս��� �� 5% ���� �߻� */
#if DEF_USE_RY_TYPE == 0
 /* 
  Y  =  0.29900Red + 0.58700Green + 0.11400Blue =   ( 77Red/256) + (150Green/256) + ( 29Blue/256)
  Cb = -0.16874Red - 0.33126Green + 0.50000Blue = - ( 44Red/256) - ( 87Green/256) + (131Blue/256) {+128}
  Cr =  0.50000Red - 0.41869Green - 0.08131Blue =   (131Red/256) - (110Green/256) + ( 21Blue/256) {+128}
 */
 s_Red &= 0xff, s_Green &= 0xff, s_Blue  &= 0xff;
 *s_Y  = (int)(  (( 77 * s_Red) >> 8) + ((150 * s_Green) >> 8) + (( 29 * s_Blue) >> 8)       );
 *s_Cb = (int)( -(( 44 * s_Red) >> 8) - (( 87 * s_Green) >> 8) + ((131 * s_Blue) >> 8) + 128 );
 *s_Cr = (int)(  ((131 * s_Red) >> 8) - ((110 * s_Green) >> 8) - (( 21 * s_Blue) >> 8) + 128 );
 *s_Y  = (int)(  (*s_Y  > 0) ? *s_Y  : 0);  *s_Y  = (int)((*s_Y  < 255) ? *s_Y  : 255        );
 *s_Cb = (int)(  (*s_Cb > 0) ? *s_Cb : 0);  *s_Cb = (int)((*s_Cb < 255) ? *s_Cb : 255        );
 *s_Cr = (int)(  (*s_Cr > 0) ? *s_Cr : 0);  *s_Cr = (int)((*s_Cr < 255) ? *s_Cr : 255        );
#else
 /* 
  Y  =  0.29900Red + 0.58700Green + 0.11400Blue =   (19595.264  Red/65536) + (38469.632  Green/65536) + (7471.104  Blue/65536)
  Cb = -0.16874Red - 0.33126Green + 0.50000Blue = - (11058.54464Red/65536) - (21709.45536Green/65536) + (32768.0   Blue/65536) {+128}
  Cr =  0.50000Red - 0.41869Green - 0.08131Blue =   (32768.0    Red/65536) - (27439.26784Green/65536) + (5328.73216Blue/65536) {+128}
 */
 s_Red &= 0xff, s_Green &= 0xff, s_Blue  &= 0xff;
 *s_Y  = (int)(  ((19595 * s_Red) >> 16) + ((38470 * s_Green) >> 16) + ((7471  * s_Blue) >> 16)       );
 *s_Cb = (int)( -((11059 * s_Red) >> 16) - ((21709 * s_Green) >> 16) + ((32768 * s_Blue) >> 16) + 128 );
 *s_Cr = (int)(  ((32768 * s_Red) >> 16) - ((27439 * s_Green) >> 16) - ((5329  * s_Blue) >> 16) + 128 );
 *s_Y  = (int)(  (*s_Y  > 0) ? *s_Y  : 0);  *s_Y  = (int)((*s_Y  < 255) ? *s_Y  : 255        );
 *s_Cb = (int)(  (*s_Cb > 0) ? *s_Cb : 0);  *s_Cb = (int)((*s_Cb < 255) ? *s_Cb : 255        );
 *s_Cr = (int)(  (*s_Cr > 0) ? *s_Cr : 0);  *s_Cr = (int)((*s_Cr < 255) ? *s_Cr : 255        );
#endif
 return;
}

void YCbCr_RGB(int s_Y, int s_Cb, int s_Cr, int *s_Red, int *s_Green, int *s_Blue)
{ /* ��ȯ�������� ���� �ս��� �� 5% ���� �߻� */
#if DEF_USE_RY_TYPE == 0 /* �Ҽ��� ���� 3�ڸ������� ��� */
 /*    
  Red   = 1.00000Y + 1.40200Cr             = s_Y + (359s_Cr{-128}/256)   
  Green = 1.00000Y - 0.34414Cb - 0.71414Cr = s_Y - ( 88s_Cb{-128}/256) - (183s_Cr{-128}/256)
  Blue  = 1.00000Y + 1.77200Cb             = s_Y + (454s_Cb{-128}/256)
 */
 s_Y &= 0xff, s_Cb &= 0xff, s_Cr &= 0xff;
 s_Cb -= 128, s_Cr -= 128;
 *(s_Red)   = (int)( s_Y + ((359*s_Cr)/256) );
 *(s_Green) = (int)( s_Y - ((88*s_Cb)/256) - ((183*s_Cr)/256) );
 *(s_Blue)  = (int)( s_Y + ((454*s_Cb)/256) );
#else                   /* �Ҽ��� ���� 6�ڸ������� ��� */
 /*    
  Red   = 1.00000Y + 1.40200Cr             = s_Y + (91881.472  s_Cr{-128}/32768)   
  Green = 1.00000Y - 0.34414Cb - 0.71414Cr = s_Y - (22553.55904s_Cb{-128}/32768) - (46801.87904s_Cr{-128}/65536)
  Blue  = 1.00000Y + 1.77200Cb             = s_Y + (116129.792 s_Cb{-128}/32768)
 */
 s_Y &= 0xff, s_Cb &= 0xff, s_Cr &= 0xff;
 s_Cb -= 128;
 s_Cr -= 128;
 *(s_Red)   = (int)( s_Y + ((91881 *s_Cr)/65536) );
 *(s_Green) = (int)( s_Y - ((22554 *s_Cb)/65536) - ((46802*s_Cr)/65536) );
 *(s_Blue)  = (int)( s_Y + ((116130*s_Cb)/65536) );
#endif
 return;
}

inline void *PPC_HowAddress(t_GDC *s_GDC, void *s_MemMap, int s_x, int s_y)
{
 return( (void *)(((unsigned char *)s_MemMap) + (s_y * s_GDC->ResY) + s_x) );   
}

void PPC_DrawPixel(t_GDC *s_GDC, void *s_MemMap, int s_Red, int s_Green, int s_Blue, int s_x, int s_y)
{
 int s_Y, s_Cb, s_Cr;
 unsigned char *s_Address;
 RGB_YCbCr(s_Red, s_Green, s_Blue, &s_Y, &s_Cb, &s_Cr);
 s_Address    = (unsigned char *)PPC_HowAddress(s_GDC, s_MemMap, s_x, s_y);
 *(s_Address) = (unsigned char)s_Y; 
 if((s_x % 2) == 0)
 {
  s_Address       += (s_GDC->ResX * s_GDC->ResY);   
  *(s_Address    ) = s_Cb;    
  *(s_Address + 1) = s_Cr;    
 }
 /* else *(s_Address) = s_Cr; */   
 return;
}

void PPC_DrawBox(t_GDC *s_GDC, void *s_MemMap, int s_Red, int s_Green, int s_Blue, int s_x1, int s_y1, int s_x2, int s_y2)
{
 int s_Y, s_Cb, s_Cr, s_Range, s_cx;
 unsigned char *s_Address;
 s_Range = s_x2 - s_x1 + 1;
 RGB_YCbCr(s_Red, s_Green, s_Blue, &s_Y, &s_Cb, &s_Cr);
 s_Address    = (unsigned char *)PPC_HowAddress(s_GDC, s_MemMap, s_x1, s_y1);
 while(s_y1 <= s_y2)
 {
  memset(s_Address, s_Y, s_Range);
  for(s_cx = s_x1;s_cx <= s_x2;s_cx++)
  {
   if((s_cx % 2) == 0)
   {   
    *(s_Address + (s_GDC->ResX * s_GDC->ResY)    ) = s_Cb;    
    *(s_Address + (s_GDC->ResX * s_GDC->ResY) + 1) = s_Cr; 
   }   
  }
  s_Address += s_GDC->ResX;
  s_y1++;
 }
 return; 
}

void PPC_DrawHLine(t_GDC *s_GDC, void *s_MemMap, int s_Red, int s_Green, int s_Blue, int s_x1, int s_x2, int s_y)
{
 PPC_DrawBox(s_GDC, s_MemMap, s_Red, s_Green, s_Blue, s_x1, s_y, s_x2, s_y);
 return; 
}

void PPC_DrawVLine(t_GDC *s_GDC, void *s_MemMap, int s_Red, int s_Green, int s_Blue, int s_x, int s_y1, int s_y2)
{
 PPC_DrawBox(s_GDC, s_MemMap, s_Red, s_Green, s_Blue, s_x, s_y1, s_x, s_y2);
 return;    
}

#endif                               /* DEF_gdc_c */

/* End of source */

