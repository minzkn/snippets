/*
 Title                               : gdc.h                                   MZLIB 
 MZLIB Source by                     : Jae Hyuk CHO                            �� �� �� 
 Copyright                           : Information Equipment co.,LTD.          (��) ������ť 
 Update                              : 2000.12.09 - New
                                       2000.12.26 - Addtion(For with C/C++)
                                       2000.12.30 - ReCoding
				       2001.01.20 - Optimize header
				       2001.07.23 - New gdc.c
 !RAW!
  DEF_ : Define
  t_   : typedef
  tx_  : typedef first field type - `x'    ( Ex: typedef enum -> typedef enum te_Bool{.......}t_Bool; )
  g_   : Global
  s_   : Local
  c_   : Const 

 E-Mail : minzkn@dreamwiz.com
          minzkn@infoeq.com
	  minzkn@infoeq.co.kr
  
*/

#ifndef DEF_gdc_h                                    /* Already include ???                  */
#define DEF_gdc_h                    "gdc.h"

 #include                            <asm/types.h>
 #include                            <sys/time.h>
 #include                            <sys/types.h>
 #include                            <sys/ioctl.h>
 #include                            <unistd.h> /* First include for POSIX standard */
 #include                            <sys/mman.h>
 #include                            <stdlib.h>
 #include                            <termios.h>

 #define FBIOGET_VSCREENINFO         0x4600
 #define FBIOPUT_VSCREENINFO         0x4601
 #define FBIOGET_FSCREENINFO         0x4602
 #define FBIOGET_CMAP                0x4604
 #define FBIOPUT_CMAP                0x4605
 #define FBIOPAN_DISPLAY             0x4606

 typedef struct ts_GDC_INFO_FB_FIX
 {
  char                               ID[16];                        /* Identification */
  void                              *PhysicalAddress;               /* Start of physical memory address */
  unsigned long                      PhysicalLength;                /* Length of frame buffer memory */
  unsigned long                      Type;                          /* Frame buffer type */  
  unsigned long                      TypeAUX;                       /* Interleave for interleaved planes */
  unsigned long                      TypeVisual;                    /* Visual type */
  unsigned short                     StepX;                         /* Step X */
  unsigned short                     StepY;                         /* Step Y */
  unsigned short                     StepXY;                        /* Step X & Y */
  unsigned long                      LineLength;                    /* Length of line in bytes */
  void                              *IOAddress;                     /* Start of I/O map address */
  unsigned long                      IOLength;                      /* I/O mapping limited */
  unsigned long                      Accel;                         /* Accel type */
  unsigned short                     Reserved[3];                   /* Reserved information area */
 }t_GDC_INFO_FB_FIX;

 typedef struct ts_GDC_FB_BIT
 {
  unsigned long                      Offset;
  unsigned long                      Length;
  unsigned long                      Right;                         /* Most significant bit is right */ 
 }t_GDC_FB_BIT;
 
 typedef struct ts_GDC_INFO_FB_VAR
 {
  unsigned long                      ResX;
  unsigned long                      ResY;
  unsigned long                      VirtualX;
  unsigned long                      VirtualY;
  unsigned long                      OffsetX;
  unsigned long                      OffsetY;
  unsigned long                      BPP;                           /* Bits per pixel */
  unsigned long                      GrayScale;
  t_GDC_FB_BIT                       RGB[3];
  t_GDC_FB_BIT                       Transparentcy;
  unsigned long                      IsStandard;
  unsigned long                      Activate;
  unsigned long                      Height;
  unsigned long                      Width;
  unsigned long                      AccelFlags;
  unsigned long                      PixClock;
  unsigned long                      LeftMargin;
  unsigned long                      RightMargin;
  unsigned long                      TopMargin;
  unsigned long                      BottomMargin;
  unsigned long                      HSyncLength;
  unsigned long                      VSyncLength;
  unsigned long                      Sync;
  unsigned long                      VMode;
  unsigned long                      Reserved[6];  
 }t_GDC_INFO_FB_VAR;
 
 typedef struct ts_HANDLE_Keyboard
 {
  int                      HANDLE;
  struct termios           OriginalTermios;
  struct termios           NewTermios;
  int                      BufferLength;
  void                    *Buffer;
  int                      InPtr, OutPtr;
  int                      Flags; /* 7:Extended , 6:Release , 5:Reserved , 4:Reserved , 3:Reserved , 2:Shift , 1:Alt , 0:Ctrl */
 }t_HANDLE_Keyboard;

 typedef struct ts_GDC
 {
  struct ts_GDC                     *Next;                          /* Multi handling */
  int                                Handle;                        /* Graphics device handle */
  t_GDC_INFO_FB_FIX                  Info_FIX;                      /* Frame buffer information fix */
  t_GDC_INFO_FB_VAR                  Info_VAR;                      /* Frame buffer information var */
  int                                ResX, ResY, ResBytes;          /* Resolution X, Y, Bytes */
  int                                Clipping[4];
  void                              *BaseAddress;                   /* Base address */
  void                              *WorkAddress;                   /* Work address - At No RGB mode */
  int                                MapSize;                       /* Memory mapping limit */
  int                                LeftAddress, RightAddress;     /* Limit address */
  int                               *OffsetX;                       /* X offset table */ 
  int                               *OffsetY;                       /* Y offset table */
  int                                FontScaleX, FontScaleX_dot;    /* Scale font X */
  int                                FontScaleY, FontScaleY_dot;    /* Font scale */
  int                                MouseHandle;                   /* Mouse handle */
  int                                MouseX, MouseY, MouseButton;   /* Mouse status */
  void                             (*MouseEvent)(struct ts_GDC *);  /* Mouse event function */
  t_HANDLE_Keyboard                 *KeyboardHandle;
  int                                UseMouseCursor;
 }t_GDC;

 #ifdef DEF_gdc_c                    /* ���ο����� ���� ���� - ����ڴ� ������!!! */

 #else

  #ifdef __cplusplus
   extern "C" {
  #endif /* __cplusplus */

extern t_GDC *OpenGDC(char *s_DeviceName, int s_ResX, int s_ResY, int s_ResBytes);
extern t_GDC *CloseGDC(t_GDC *s_HANDLE_GDC);
extern inline int __GDC_Check(t_GDC *s_HANDLE_GDC, int s_x, int s_y);
extern inline void __GDC_CheckSwap(int *s_Min, int *s_Max);
extern inline void __GDC_CheckLimitX(t_GDC *s_HANDLE_GDC, int *s_x);
extern inline void __GDC_CheckLimitY(t_GDC *s_HANDLE_GDC, int *s_y);
extern int __GDC_GetPixel_01(t_GDC *s_HANDLE_GDC, int s_x, int s_y);
extern int __GDC_GetPixel_02(t_GDC *s_HANDLE_GDC, int s_x, int s_y);
extern int __GDC_GetPixel_03(t_GDC *s_HANDLE_GDC, int s_x, int s_y);
extern int __GDC_GetPixel_04(t_GDC *s_HANDLE_GDC, int s_x, int s_y);
extern inline int GDC_GetPixel(t_GDC *s_HANDLE_GDC, int s_x, int s_y);
extern void __GDC_SetPixel_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y);
extern void __GDC_SetPixel_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y);
extern void __GDC_SetPixel_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y);
extern void __GDC_SetPixel_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y);
extern inline void GDC_SetPixel(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y);
extern inline void GDC_DrawPixel(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y);
extern void __GDC_GetHLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
extern void __GDC_GetHLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
extern void __GDC_GetHLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
extern void __GDC_GetHLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
extern inline void GDC_GetHLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
extern void __GDC_SetHLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
extern void __GDC_SetHLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
extern void __GDC_SetHLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
extern void __GDC_SetHLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
extern inline void GDC_SetHLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_x2, int s_y);
extern void __GDC_DrawHLine_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
extern void __GDC_DrawHLine_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
extern void __GDC_DrawHLine_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
extern void __GDC_DrawHLine_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
extern inline void GDC_DrawHLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
extern void __GDC_XORHLine_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
extern void __GDC_XORHLine_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
extern void __GDC_XORHLine_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
extern void __GDC_XORHLine_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
extern inline void GDC_XORHLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_x2, int s_y);
extern void __GDC_GetVLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
extern void __GDC_GetVLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
extern void __GDC_GetVLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
extern void __GDC_GetVLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
extern inline void GDC_GetVLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
extern void __GDC_SetVLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
extern void __GDC_SetVLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
extern void __GDC_SetVLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
extern void __GDC_SetVLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
extern inline void GDC_SetVLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y1, int s_y2);
extern void __GDC_DrawVLine_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
extern void __GDC_DrawVLine_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
extern void __GDC_DrawVLine_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
extern void __GDC_DrawVLine_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
extern inline void GDC_DrawVLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
extern void __GDC_XORVLine_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
extern void __GDC_XORVLine_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
extern void __GDC_XORVLine_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
extern void __GDC_XORVLine_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
extern inline void GDC_XORVLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x, int s_y1, int s_y2);
extern void __GDC_GetBox_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_GetBox_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_GetBox_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_GetBox_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
extern inline void GDC_GetBox(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_SetBox_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_SetBox_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_SetBox_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_SetBox_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
extern inline void GDC_SetBox(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_DrawBox_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_DrawBox_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_DrawBox_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_DrawBox_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
extern inline void GDC_DrawBox(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_XORBox_01(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_XORBox_02(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_XORBox_03(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
extern void __GDC_XORBox_04(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
extern inline void GDC_XORBox(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
extern void *__GDC_GetLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
extern void *__GDC_GetLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
extern void *__GDC_GetLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
extern void *__GDC_GetLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
extern void GDC_GetLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
extern void *__GDC_SetLine_01(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
extern void *__GDC_SetLine_02(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
extern void *__GDC_SetLine_03(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
extern void *__GDC_SetLine_04(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x, int s_y);
extern void GDC_SetLine(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_x1, int s_y1, int s_x2, int s_y2);
extern void GDC_DrawLine(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
extern inline void GDC_Bitmap8x16(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_Color, int s_BackColor, int s_x, int s_y);
extern inline void GDC_Bitmap16x16(t_GDC *s_HANDLE_GDC, void *s_Buffer, int s_Color, int s_BackColor, int s_x, int s_y);
extern inline void GDC_DrawEnglish(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, int s_Character, int s_x, int s_y);
extern void GDC_DrawHangul(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, int s_Character, int s_x, int s_y);
extern inline void GDC_GetFontSize(t_GDC *s_HANDLE_GDC, int *s_SizeX, int *s_SizeY);
extern inline void GDC_SetFontSize(t_GDC *s_HANDLE_GDC, int s_SizeX, int s_SizeY);
extern inline void GDC_ClearScreen(t_GDC *s_HANDLE_GDC, int s_Color);
extern inline void GDC_ConvertKStoJO(unsigned short *s_HangulCode);
extern void GDC_DrawPutsEnglish(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, void *s_String, int s_x, int s_y);
extern void GDC_DrawPutsHangul(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, void *s_String, int s_x, int s_y);
extern void GDC_DrawPrintfEnglish(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, int s_x, int s_y, void *s_FormatString, ...);
extern void GDC_DrawPrintfHangul(t_GDC *s_HANDLE_GDC, int s_Color, int s_BackColor, int s_x, int s_y, void *s_FormatString, ...);
extern inline void GDC_DrawRec3D(t_GDC *s_HANDLE_GDC, int s_LColor, int s_RColor, int s_x1, int s_y1, int s_x2, int s_y2);
extern void GDC_DrawRectangle(t_GDC *s_HANDLE_GDC, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
extern void GDC_DrawBox3D(t_GDC *s_HANDLE_GDC, int s_LColor, int s_RColor, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
extern int GDC_Color(int s_Red, int s_Green, int s_Blue);
extern int GDC_Color256(int s_Red, int s_Green, int s_Blue);
extern void GDC_DrawButton(t_GDC *s_HANDLE_GDC, int s_Switch, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2);
extern int GDC_OpenMouse(t_GDC *s_HANDLE_GDC, void (*s_MouseEvent)(struct ts_GDC *));
extern void GDC_CloseMouse(t_GDC *s_HANDLE_GDC);
extern int __GDC_GetMouse(t_GDC *s_HANDLE_GDC, int *s_x, int *s_y, int *s_Button);
extern void GDC_MouseCursor(t_GDC *s_HANDLE_GDC, int s_Type);
extern void GDC_MouseProcess(t_GDC *s_HANDLE_GDC);
extern int GDC_MouseArea(t_GDC *s_HANDLE_GDC, int s_x1, int s_y1, int s_x2, int s_y2);
extern int GDC_LoadJpeg(t_GDC *s_HANDLE_GDC, void *s_JpegName, int s_x, int s_y);
extern int GDC_LoadGif(t_GDC *s_HANDLE_GDC, void *s_GifName, int s_x, int s_y);
extern int GDC_Percent(int s_SMin, int s_SMax, int s_Current, int s_TMin, int s_TMax);
extern void GDC_UpdateBox(t_GDC *s_HANDLE_GDC, void *s_Source, void *s_Target, int s_x1, int s_y1, int s_x2, int s_y2);
extern void GDC_Scroll(t_GDC *s_HANDLE_GDC, int s_Arrow, int s_Color, int s_x1, int s_y1, int s_x2, int s_y2, int s_Grid);
extern t_HANDLE_Keyboard *MZKEY_OPEN(const char *s_KeyboardDevice);
extern t_HANDLE_Keyboard *MZKEY_CLOSE(t_HANDLE_Keyboard *s_HANDLE_Keyboard);
extern int MZKEY_PROCESS(t_HANDLE_Keyboard *s_HANDLE_Keyboard);
extern int MZKEY_READKEY(t_HANDLE_Keyboard *s_HANDLE_Keyboard);
extern t_HANDLE_Keyboard *GDC_OpenKeyboard(t_GDC *s_HANDLE_GDC, char *s_DeviceName);
extern int GDC_KeyboardProcess(t_GDC *s_HANDLE_GDC);
extern int GDC_GetKey(t_GDC *s_HANDLE_GDC);
extern void GDC_CloseKeyboard(t_GDC *s_HANDLE_GDC);  
extern void GDC_Blender16(t_GDC *s_GDC, unsigned int s_AlphaR, unsigned int s_AlphaG, unsigned int s_AlphaB, int s_x1, int s_y1, int s_x2, int s_y2);

extern int (*_GDC_GetPixel[])(t_GDC *, int, int); 
extern void (*_GDC_SetPixel[])(t_GDC *, int, int, int);
extern void (*_GDC_GetHLine[])(t_GDC *, void *, int, int, int);
extern void (*_GDC_SetHLine[])(t_GDC *, void *, int, int, int);
extern void (*_GDC_DrawHLine[])(t_GDC *, int, int, int, int);
extern void (*_GDC_GetVLine[])(t_GDC *, void *, int, int, int);
extern void (*_GDC_SetVLine[])(t_GDC *, void *, int, int, int);
extern void (*_GDC_DrawVLine[])(t_GDC *, int, int, int, int);
extern void (*_GDC_GetBox[])(t_GDC *, void *, int, int, int, int);
extern void (*_GDC_SetBox[])(t_GDC *, void *, int, int, int, int);
extern void (*_GDC_DrawBox[])(t_GDC *, int, int, int, int, int);
extern void *(*_GDC_GetLine[])(t_GDC *, void *, int, int);
extern void *(*_GDC_SetLine[])(t_GDC *, void *, int, int);

extern unsigned char g_HAN_table0[32U];
extern unsigned char g_HAN_table1[32U];
extern unsigned char g_HAN_table2[32U];
extern unsigned char g_HAN_ftable0[21U];
extern unsigned char g_HAN_ftable1[21U];
extern unsigned char g_HAN_ltable[21U];
extern unsigned short g_HAN_KSTable[2350];
extern unsigned short g_HAN_SingleTable[51];
extern unsigned short g_MouseCursor[5][16];

extern t_GDC *g_GDC_Main;

  #ifdef __cplusplus
   }    
  #endif /* __cplusplus */     

 #endif                                          /* DEF_gdc_c                       */

#endif                                           /* DEF_gdc_h                       */

/* End of source */
