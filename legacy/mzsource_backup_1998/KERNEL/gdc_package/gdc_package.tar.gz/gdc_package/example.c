/*
 Example code by JaeHyuk Cho
 GDC Library Version 0.4.0

 Licence : GPL licence
*/

#include "gdc.h"

int main(void)
{
 t_GDC *s_HANDLE_GDC;
 s_HANDLE_GDC = OpenGDC("/dev/fb0", (-1), (-1), (-1)); /* Auto resolution, 16bit color, framebuffer */
 if(s_HANDLE_GDC)
 {

  /* ------ */
  GDC_DrawBox(s_HANDLE_GDC, GDC_Color(63, 63, 63), 100, 100, 200, 200); /* White color box */ 
  GDC_DrawPrintfHangul(s_HANDLE_GDC, GDC_Color(0, 0, 0), (-1), 100, 100, "Hangul message : XXXXX %s", __DATE__); 
  if(s_HANDLE_GDC->ResBytes == 2) // 16bit color?
  {
   GDC_Blender16(s_HANDLE_GDC, 80, 80, 150, 140, 140, 160, 160); // Alpha blending  RED=80% , GREEN=80% , BLUE=150% 
  }
  /* ------ */

  s_HANDLE_GDC = CloseGDC(s_HANDLE_GDC);  /* Close framebuffer */
 }
 /* else fprintf(stdout, "Can not open device !!!\n"); */
 return(0);
}

/* End of source */
